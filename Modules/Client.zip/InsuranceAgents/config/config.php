<?php

return [
    'name' => 'InsuranceAgents',
];
