<?php

namespace Modules\InsuranceAgents\Database\Seeders;

use Illuminate\Database\Seeder;

class InsuranceAgentsDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
