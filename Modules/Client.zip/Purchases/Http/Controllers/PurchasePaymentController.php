<?php

namespace Modules\Purchases\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\Sales\ClientPaymentRequest;
use App\Models\Account;
use App\Models\Employee;
use App\Models\JournalEntry;
use App\Models\JournalEntryDetail;
use App\Models\PaymentsProcess;
use App\Models\PurchaseInvoice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class PurchasePaymentController extends Controller
{
    public function index(Request $request)
    {
        $employees = Employee::all();

        $query = PaymentsProcess::with(['purchase', 'employee'])
            ->where('type', 'purchase payments');

        // رقم الفاتورة
        if ($request->filled('invoice_number')) {
            $query->whereHas('purchase', function ($q) use ($request) {
                $q->where('code', 'like', '%' . $request->invoice_number . '%');
            });
        }

        // رقم عملية الدفع
        if ($request->filled('payment_number')) {
            $query->where('payment_number', 'like', '%' . $request->payment_number . '%');
        }

        // العميل
        if ($request->filled('customer_id')) {
            $query->whereHas('purchase', function ($q) use ($request) {
                $q->where('supplier_id', $request->customer_id);
            });
        }

        // وسيلة دفع
        if ($request->filled('payment_method')) {
            $query->where('payment_method', $request->payment_method);
        }

        // تخصيص التاريخ
        if ($request->filled('date_type')) {
            switch ($request->date_type) {
                case '1': // شهرياً
                    $query->whereMonth('date', now()->month);
                    break;
                case '0': // أسبوعياً
                    $query->whereBetween('date', [now()->startOfWeek(), now()->endOfWeek()]);
                    break;
                case '2': // يومياً
                    $query->whereDate('date', now());
                    break;
            }
        }

        // من تاريخ - إلى تاريخ
        if ($request->filled('from_date') && $request->filled('to_date')) {
            $query->whereBetween('date', [$request->from_date, $request->to_date]);
        }

        // الاجمالي اكبر من
        if ($request->filled('total_min')) {
            $query->where('amount', '>=', $request->total_min);
        }

        // الاجمالي اصغر من
        if ($request->filled('total_max')) {
            $query->where('amount', '<=', $request->total_max);
        }

        // حالة الدفع
        if ($request->filled('payment_status')) {
            $query->where('payment_status', $request->payment_status);
        }

        // تاريخ الانشاء - تخصيص
        if ($request->filled('creation_date_type')) {
            switch ($request->creation_date_type) {
                case '1': // شهرياً
                    $query->whereMonth('created_at', now()->month);
                    break;
                case '0': // أسبوعياً
                    $query->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]);
                    break;
                case '2': // يومياً
                    $query->whereDate('created_at', now());
                    break;
            }
        }

        // تاريخ الانشاء - من تاريخ إلى تاريخ
        if ($request->filled('creation_from_date') && $request->filled('creation_to_date')) {
            $query->whereBetween('created_at', [$request->creation_from_date, $request->creation_to_date]);
        }

        // منشئ الفاتورة
        if ($request->filled('created_by')) {
            $query->where('created_by', $request->created_by);
        }

        $payments = $query->paginate(25);

        return view('purchases::purchases.Supplier_Payments.index', compact('payments', 'employees'));
    }

    public function create($id)
    {
        // التحقق من وجود الفاتورة وعدم دفعها بالكامل
        $invoice = PurchaseInvoice::findOrFail($id);

        if ($invoice->is_paid) {
            return redirect()->route('invoicePurchases.index')->with('error', 'لا يمكن إضافة دفعة. الفاتورة مدفوعة بالكامل بالفعل.');
        }

        $payments = PaymentsProcess::where('invoice_id', $id)->get();
        $employees = Employee::all();

        return view('purchases::purchases.supplier_payments.create', compact('payments', 'employees', 'id', 'invoice'));
    }

    public function store(ClientPaymentRequest $request)
    {
        try {
            DB::beginTransaction();

            // استرجاع البيانات المصادق عليها
            $data = $request->validated();

            // التحقق من وجود الفاتورة وجلب تفاصيلها
            $invoice = PurchaseInvoice::findOrFail($data['invoice_id']);

            // ** التحقق المسبق من حالة الفاتورة **
            if ($invoice->is_paid) {
                return back()->with('error', 'لا يمكن إضافة دفعة. الفاتورة مدفوعة بالكامل بالفعل.')->withInput();
            }

            // حساب إجمالي المدفوعات السابقة
            $totalPreviousPayments = PaymentsProcess::where('invoice_id', $invoice->id)
                ->where('type', 'purchase payments')
                ->where('payment_status', '!=', 5) // استثناء المدفوعات الفاشلة
                ->sum('amount');

            // حساب المبلغ المتبقي للدفع
            $remainingAmount = $invoice->grand_total - $totalPreviousPayments;

            // التحقق من أن مبلغ الدفع لا يتجاوز المبلغ المتبقي
            if ($data['amount'] > $remainingAmount) {
                return back()
                    ->with('error', 'مبلغ الدفع يتجاوز المبلغ المتبقي للفاتورة. المبلغ المتبقي هو: ' . number_format($remainingAmount, 2))
                    ->withInput();
            }

            // تعيين حالة الدفع الافتراضية كمسودة
            $payment_status = 3; // مسودة

            // تحديد حالة الدفع بناءً على المبلغ المدفوع والمبلغ المتبقي
            $newTotalPayments = $totalPreviousPayments + $data['amount'];

            if ($newTotalPayments >= $invoice->grand_total) {
                $payment_status = 1; // مكتمل
                $invoice->is_paid = true;
                $invoice->due_value = 0;
            } else {
                $payment_status = 2; // غير مكتمل
                $invoice->is_paid = false;
                $invoice->due_value = $invoice->grand_total - $newTotalPayments;
            }

            // إضافة البيانات الإضافية للدفعة
            $data['type'] = 'purchase payments';
            $data['created_by'] = Auth::id();
            $data['payment_status'] = $payment_status;

            // معالجة المرفقات
            if ($request->hasFile('attachments')) {
                $file = $request->file('attachments');
                if ($file->isValid()) {
                    $filename = time() . '_' . $file->getClientOriginalName();
                    $file->move(public_path('assets/uploads/'), $filename);
                    $data['attachments'] = $filename;
                }
            }

            // إنشاء سجل الدفع
            $payment = PaymentsProcess::create($data);

            // تحديث المبلغ المدفوع في الفاتورة
            $invoice->advance_payment = $newTotalPayments;
            $invoice->payment_status = $payment_status;
            $invoice->save();

            // إنشاء قيد محاسبي للدفعة
            $this->createPaymentJournalEntry($invoice, $data['amount']);

            DB::commit();

            // إعداد رسالة النجاح مع حالة الدفع
            $paymentStatusText = match ($payment_status) {
                1 => 'مكتمل',
                2 => 'غير مكتمل',
                3 => 'مسودة',
                4 => 'تحت المراجعة',
                5 => 'فاشلة',
                default => 'غير معروف',
            };

            $successMessage = sprintf('تم تسجيل عملية الدفع بنجاح. المبلغ المدفوع: %s، المبلغ المتبقي: %s - حالة الدفع: %s', number_format($data['amount'], 2), number_format($invoice->due_value, 2), $paymentStatusText);

            return redirect()->route('paymentsPurchase.index')->with('success', $successMessage);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('خطأ في تسجيل عملية الدفع: ' . $e->getMessage());
            return back()
                ->with('error', 'حدث خطأ أثناء تسجيل عملية الدفع: ' . $e->getMessage())
                ->withInput();
        }
    }

    public function show($id)
    {
        try {
            $payment = PaymentsProcess::with(['purchase.supplier', 'purchase', 'employee'])
                ->where('type', 'purchase payments')
                ->findOrFail($id);

            $employees = Employee::all();

            return view('purchases::purchases.supplier_payments.show', compact('payment', 'employees'));
        } catch (\Exception $e) {
            return redirect()
                ->route('PaymentSupplier.indexPurchase')
                ->with('error', 'حدث خطأ أثناء عرض تفاصيل الدفع: ' . $e->getMessage());
        }
    }

    public function edit($id)
    {
        $payment = PaymentsProcess::with(['purchase', 'employee'])->findOrFail($id);
        $employees = Employee::all();
        return view('purchases::purchases.Supplier_Payments.edit', compact('payment', 'employees', 'id'));
    }

    public function update(ClientPaymentRequest $request, PaymentsProcess $payment)
    {
        try {
            // استرجاع البيانات المصادق عليها
            $data = $request->validated();

            // معالجة المرفقات
            if ($request->hasFile('attachments')) {
                $data['attachments'] = $request->file('attachments')->store('payment_attachments', 'public');
            }

            // تحديث السجل
            $payment->update($data);

            return redirect()->route('paymentsPurchase.index')->with('success', 'تم تحديث عملية الدفع بنجاح');
        } catch (\Exception $e) {
            return back()
                ->with('error', 'حدث خطأ أثناء تحديث عملية الدفع: ' . $e->getMessage())
                ->withInput();
        }
    }

    public function destroy($id)
    {
        PaymentsProcess::destroy($id);
        return redirect()->route('paymentsPurchase.index')->with('success', 'تم حذف عملية الدفع بنجاح');
    }

    public function getInvoiceDetails($invoice_id)
    {
        try {
            $invoice = PurchaseInvoice::findOrFail($invoice_id);

            // حساب المبلغ المدفوع والمتبقي
            $totalPayments = PaymentsProcess::where('invoice_id', $invoice->id)->where('type', 'purchase payments')->sum('amount');

            $remainingAmount = $invoice->grand_total - $totalPayments;

            return response()->json([
                'success' => true,
                'data' => [
                    'invoice' => $invoice,
                    'total_paid' => $totalPayments,
                    'remaining_amount' => $remainingAmount,
                    'client_name' => $invoice->supplier->name ?? 'غير محدد',
                    'invoice_date' => $invoice->invoice_date,
                    'grand_total' => $invoice->grand_total,
                    'payment_status' => $invoice->payment_status,
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => 'حدث خطأ أثناء جلب تفاصيل الفاتورة: ' . $e->getMessage(),
                ],
                500,
            );
        }
    }

    // دالة مساعدة لإنشاء القيد المحاسبي للدفعة
    private function createPaymentJournalEntry($invoice, $amount)
    {
        // إنشاء قيد محاسبي للدفعة
        $journalEntry = JournalEntry::create([
            'reference_number' => 'PAY-' . time(),
            'date' => now(),
            'description' => 'دفعة للفاتورة رقم ' . $invoice->code,
            'status' => 1,
            'currency' => 'SAR',
            'supplier_id' => $invoice->supplier_id,
            'invoice_id' => $invoice->id,
        ]);

        // إضافة تفاصيل القيد
        // مدين - حساب النقدية
        JournalEntryDetail::create([
            'journal_entry_id' => $journalEntry->id,
            'account_id' => $invoice->account_id, // حساب الصندوق أو البنك
            'description' => 'دفعة نقدية',
            'debit' => $amount,
            'credit' => 0,
            'is_debit' => true,
        ]);

        // دائن - حساب المورد
        JournalEntryDetail::create([
            'journal_entry_id' => $journalEntry->id,
            'account_id' => $invoice->supplier->account_id,
            'description' => 'تسديد دفعة',
            'debit' => 0,
            'credit' => $amount,
            'is_debit' => false,
        ]);
    }
}
