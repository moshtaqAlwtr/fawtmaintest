<?php

namespace Modules\Purchases\Database\Seeders;

use Illuminate\Database\Seeder;

class PurchasesDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
