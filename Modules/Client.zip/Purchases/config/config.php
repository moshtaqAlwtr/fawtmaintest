<?php

return [
    'name' => 'Purchases',
];
