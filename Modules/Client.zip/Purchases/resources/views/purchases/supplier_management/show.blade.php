@extends('master')

@section('title')
    عرض المورد
@stop
@section('css')
    <style>
        .timeline {
            position: relative;
            margin: 20px 0;
            padding: 0;
            list-style: none;
        }

        .timeline::before {
            content: '';
            position: absolute;
            top: 50px;
            bottom: 0;
            width: 4px;
            background: linear-gradient(180deg, #28a745 0%, #218838 100%);
            right: 50px;
            margin-right: -2px;
        }

        .timeline-item {
            margin: 0 0 20px;
            padding-right: 100px;
            position: relative;
            text-align: right;
        }

        .timeline-item::before {
            content: "\f067";
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            position: absolute;
            right: 30px;
            top: 15px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(145deg, #28a745, #218838);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #ffffff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .timeline-content {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .timeline-content .time {
            font-size: 14px;
            color: #6c757d;
            margin-bottom: 10px;
        }

        .timeline-day {
            background-color: #ffffff;
            padding: 10px 20px;
            border-radius: 30px;
            text-align: center;
            margin-bottom: 20px;
            font-weight: bold;
            color: #333;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            display: inline-block;
            position: relative;
            top: 0;
            right: 50px;
            transform: translateX(50%);
        }

        .timeline-date {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin: 20px 0;
            color: #333;
        }
    </style>

@endsection
@section('content')
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-left mb-0">عرض المورد</h2>
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="">الرئيسيه</a></li>

                            <li class="breadcrumb-item active">عرض</li>

                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <a href="{{ route('SupplierManagement.edit', $supplier->id) }}" class="btn btn-success">
                    <i class="fa fa-edit me-1"></i>
                    تعديل المورد
                </a>

                <div class="text-end">
    <h5 class="text-muted mb-0">{{ $supplier->trade_name }} # {{ $supplier->id }}</h5>
    <small class="text-muted">
    @if($supplier->account)
        حساب الأستاذ:
        <a href="{{ route('accounts_chart.index', $supplier->account->id) }}" class="text-primary">
            {{ $supplier->account->name }}-{{ $supplier->account->code }}
        </a>
    @else
        <span class="text-danger">لا يوجد حساب مرتبط</span>
    @endif
</small>
</div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-title p-2 d-flex align-items-center gap-2">

            <a href="{{ route('SupplierManagement.edit', $supplier->id) }}"
                class="btn btn-outline-primary btn-sm d-inline-flex align-items-center justify-content-center px-3"
                style="min-width: 90px;">
                تعديل البيانات <i class="fa fa-edit ms-1"></i>


                <a href="#" class="btn btn-outline-success btn-sm d-inline-flex align-items-center justify-content-center px-3"
   style="min-width: 90px;" data-bs-toggle="modal" data-bs-target="#modal_opening_balance">
    إضافة رصيد افتتاحي <i class="fa fa-plus-circle ms-1"></i>
</a>
                <div class="vr"></div>

                <a href="{{ route('SupplierManagement.statement', $supplier->id) }}"
                    class="btn btn-outline-info btn-sm d-inline-flex align-items-center justify-content-center px-3"
                    style="min-width: 90px;">
                    كشف حساب <i class="fa fa-file-text ms-1"></i>
                </a>
                <div class="vr"></div>

                <a href="{{ route('invoicePurchases.create', ['supplier_id' => $supplier->id ]) }}"
    class="btn btn-outline-dark btn-sm d-inline-flex align-items-center justify-content-center px-3"
    style="min-width: 90px;">
    إنشاء فاتورة شراء <i class="fa fa-shopping-cart ms-1"></i>
</a>
                <div class="vr"></div>
            </a>

            <a href="#"
                class="btn btn-outline-primary btn-sm d-inline-flex align-items-center justify-content-center px-3"
                style="min-width: 90px;">
                أضف رصيد مدفوعات <i class="fa fa-money ms-1"></i>
            </a>
            <div class="vr"></div>

            @if($supplier->status == 1)
    <button onclick="changeStatus({{ $supplier->id }}, 0, '{{ $supplier->name }}')"
            class="btn btn-outline-danger btn-sm d-inline-flex align-items-center justify-content-center px-3"
            style="min-width: 90px;">
        إيقاف <i class="fa fa-ban ms-1"></i>
    </button>
@else
    <button onclick="changeStatus({{ $supplier->id }}, 1, '{{ $supplier->name }}')"
            class="btn btn-outline-success btn-sm d-inline-flex align-items-center justify-content-center px-3"
            style="min-width: 90px;">
        تفعيل <i class="fa fa-check ms-1"></i>
    </button>
@endif
            <div class="vr"></div>

            <a href="#"
                class="btn btn-outline-danger btn-sm d-inline-flex align-items-center justify-content-center px-3"
                style="min-width: 90px;" data-bs-toggle="modal" data-bs-target="#modal_DELETE1">
                حذف <i class="fa fa-trash ms-1"></i>
            </a>


        </div>

        <!-- Modal Delete -->
        <div class="modal fade" id="modal_DELETE1" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title">حذف المورد</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>هل أنت متأكد من حذف هذا المورد؟</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">إلغاء</button>
                        <form action="{{ route('SupplierManagement.destroy', $supplier->id) }}" method="POST"
                            class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">حذف</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#details" role="tab">
                        <span>التفاصيل</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#activity" role="tab">
                        <span>سجل النشاطات</span>
                    </a>
                </li>
            </ul>

           <!-- إصلاح التبويبات -->
<div class="tab-content p-3">
    <!-- تبويب التفاصيل -->
    <div class="tab-pane active" id="details" role="tabpanel">
        <!-- محتوى التفاصيل -->
    </div>

    <!-- تبويب سجل النشاطات - إصلاح الـ ID -->
    <div class="tab-pane" id="activity" role="tabpanel">
        <div class="row mt-4">
            <div class="col-12">
                @if ($logs && count($logs) > 0)
                    @php
                        $previousDate = null;
                    @endphp

                    @foreach ($logs as $date => $dayLogs)
                        @php
                            $currentDate = \Carbon\Carbon::parse($date);
                            $diffInDays = $previousDate ? $previousDate->diffInDays($currentDate) : 0;
                        @endphp

                        @if ($diffInDays > 7)
                            <div class="timeline-date">
                                <h4>{{ $currentDate->format('Y-m-d') }}</h4>
                            </div>
                        @endif

                        <div class="timeline-day">{{ $currentDate->translatedFormat('l') }}</div>

                        <ul class="timeline">
                            @foreach ($dayLogs as $log)
                                @if ($log)
                                    <li class="timeline-item">
                                        <div class="timeline-content">
                                            <div class="time">
                                                <i class="far fa-clock"></i>
                                                {{ $log->created_at->format('H:i:s') }}
                                            </div>
                                            <div>
                                                <strong>{{ $log->user->name ?? 'مستخدم غير معروف' }}</strong>
                                                {!! Str::markdown($log->description ?? 'لا يوجد وصف') !!}
                                                <div class="text-muted">
                                                    {{ $log->user->branch->name ?? 'فرع غير معروف' }}
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                @endif
                            @endforeach
                        </ul>

                        @php
                            $previousDate = $currentDate;
                        @endphp
                    @endforeach
                @else
                    <div class="alert alert-info text-center" role="alert">
                        <i class="fas fa-info-circle mb-2"></i>
                        <p class="mb-0">لا توجد سجلات نشاط حتى الآن!</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
        </div>
    </div>
<!-- Modal Opening Balance -->
<div class="modal fade" id="modal_opening_balance" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">إضافة رصيد افتتاحي للمورد</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="openingBalanceForm" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="opening_balance" class="form-label">المبلغ (SAR)</label>
                        <input type="number" step="0.01" class="form-control" id="opening_balance"
                               name="opening_balance" required placeholder="أدخل المبلغ الافتتاحي">
                    </div>
                    <p>هل أنت متأكد من إضافة رصيد افتتاحي للمورد <strong>{{ $supplier->trade_name }}</strong>؟</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-success">حفظ</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
// دالة تغيير حالة المورد
function changeStatus(supplierId, newStatus, supplierName) {
    const statusText = newStatus == 1 ? 'تفعيل' : 'إيقاف';
    const statusColor = newStatus == 1 ? '#28a745' : '#dc3545';
    const icon = newStatus == 1 ? 'success' : 'warning';

    Swal.fire({
        title: `${statusText} المورد`,
        html: `هل أنت متأكد من <strong>${statusText}</strong> المورد <br><strong>"${supplierName}"</strong>؟`,
        icon: icon,
        showCancelButton: true,
        confirmButtonColor: statusColor,
        cancelButtonColor: '#6c757d',
        confirmButtonText: `نعم، ${statusText}`,
        cancelButtonText: 'إلغاء',
        reverseButtons: true,
        customClass: {
            confirmButton: 'btn btn-primary me-2',
            cancelButton: 'btn btn-secondary'
        },
        buttonsStyling: false
    }).then((result) => {
        if (result.isConfirmed) {
            // عرض مؤشر التحميل
            Swal.fire({
                title: 'جاري التحديث...',
                text: 'يرجى الانتظار',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // إرسال طلب AJAX
            $.ajax({
                url: `/SupplierManagement/${supplierId}/update-status`,
                type: 'POST',
                data: {
                    status: newStatus,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'تم بنجاح!',
                            text: response.message,
                            icon: 'success',
                            timer: 2000,
                            showConfirmButton: false
                        }).then(() => {
                            // تحديث الجدول بدون إعادة تحميل
                            performSearch();
                        });
                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: response.message || 'حدث خطأ أثناء تحديث الحالة',
                            icon: 'error',
                            confirmButtonText: 'موافق'
                        });
                    }
                },
                error: function(xhr) {
                    let errorMessage = 'حدث خطأ غير متوقع';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }

                    Swal.fire({
                        title: 'خطأ!',
                        text: errorMessage,
                        icon: 'error',
                        confirmButtonText: 'موافق'
                    });
                }
            });
        }
    });
}


</script>
<script>
// معالجة إرسال نموذج الرصيد الافتتاحي
$('#openingBalanceForm').on('submit', function(e) {
    e.preventDefault();

    const form = $(this);
    const supplierName = "{{ $supplier->trade_name }}";
    const amount = $('#opening_balance').val();

    Swal.fire({
        title: 'تأكيد إضافة الرصيد',
        html: `هل أنت متأكد من إضافة رصيد افتتاحي بقيمة <strong>${amount} SAR</strong> للمورد <strong>"${supplierName}"</strong>؟`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'نعم، إضافة',
        cancelButtonText: 'إلغاء',
        reverseButtons: true,
        customClass: {
            confirmButton: 'btn btn-success me-2',
            cancelButton: 'btn btn-secondary'
        },
        buttonsStyling: false
    }).then((result) => {
        if (result.isConfirmed) {
            // عرض مؤشر التحميل
            Swal.fire({
                title: 'جاري الإضافة...',
                text: 'يرجى الانتظار',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // إرسال طلب AJAX
            $.ajax({
                url: "{{ route('SupplierManagement.updateOpeningBalance', $supplier->id) }}",
                type: 'POST',
                data: form.serialize(),
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'تم بنجاح!',
                            text: 'تم إضافة الرصيد الافتتاحي بنجاح',
                            icon: 'success',
                            timer: 2000,
                            showConfirmButton: false
                        }).then(() => {
                            // إغلاق النافذة وتحديث الصفحة
                            $('#modal_opening_balance').modal('hide');
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: response.message || 'حدث خطأ أثناء إضافة الرصيد',
                            icon: 'error',
                            confirmButtonText: 'موافق'
                        });
                    }
                },
                error: function(xhr) {
                    let errorMessage = 'حدث خطأ غير متوقع';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }

                    Swal.fire({
                        title: 'خطأ!',
                        text: errorMessage,
                        icon: 'error',
                        confirmButtonText: 'موافق'
                    });
                }
            });
        }
    });
});
</script>
@endsection

