@extends('master')

@section('title')
    تعديل فاتورة مشتريات #{{ $invoice->invoice_number }}
@stop

@section('css')
    <link rel="stylesheet" href="{{ asset('assets/css/purch.css') }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-left mb-0">تعديل فاتورة مشتريات #{{ $invoice->invoice_number }}</h2>
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="">الرئيسيه</a></li>
                            <li class="breadcrumb-item"><a href="{{ route('invoicePurchases.index') }}">فواتير المشتريات</a></li>
                            <li class="breadcrumb-item active">تعديل فاتورة</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content-body">
        <form id="invoice-form" action="{{ route('invoicePurchases.update', $invoice->id) }}" method="post">
            @csrf
            @method('PUT')
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @if (session('error'))
                <div class="alert alert-danger">
                    {{ session('error') }}
                </div>
            @endif
            @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center flex-wrap">
                        <div>
                            <label>الحقول التي عليها علامة <span style="color: red">*</span> الزامية</label>
                            <br>
                            <small class="text-muted">حالة الفاتورة:
                                <span class="badge badge-{{ $invoice->status == 'paid' ? 'success' : ($invoice->status == 'draft' ? 'secondary' : 'warning') }}">
                                    {{ $invoice->status == 'paid' ? 'مدفوعة' : ($invoice->status == 'draft' ? 'مسودة' : 'معلقة') }}
                                </span>
                            </small>
                        </div>

                        <div class="d-flex">
                            <div class="btn-group mr-2" style="margin-left: 10px;">
                                <button type="button" class="btn btn-outline-info btn-sm" onclick="saveAsDraft()" title="حفظ كمسودة">
                                    <i class="fa fa-save"></i> مسودة
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="duplicateInvoice()" title="تكرار الفاتورة">
                                    <i class="fa fa-copy"></i> تكرار
                                </button>
                                <button type="button" class="btn btn-outline-danger btn-sm" onclick="deleteInvoice()" title="حذف الفاتورة">
                                    <i class="fa fa-trash"></i> حذف
                                </button>
                                <button type="button" class="btn btn-outline-success btn-sm" onclick="showQuickPreview()" title="معاينة سريعة">
                                    <i class="fa fa-eye"></i> معاينة
                                </button>
                            </div>
                            <div>
                                <a href="{{ route('invoicePurchases.index') }}" class="btn btn-outline-danger">
                                    <i class="fa fa-ban"></i>الغاء
                                </a>
                                <button type="submit" class="btn btn-outline-primary">
                                    <i class="fa fa-save"></i>حفظ التغييرات
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group row">
                                            <div class="col-md-2">
                                                <span>المورد :</span>
                                            </div>
                                            <div class="col-md-6">
                                                <select class="form-control select2" id="clientSelect" name="supplier_id"
                                                    required onchange="showSupplierBalance(this)">
                                                    <option value="">اختر المورد</option>
                                                    @foreach ($suppliers as $supplier)
                                                        <option value="{{ $supplier->id }}"
                                                            data-balance="{{ $supplier->account->balance ?? 0 }}"
                                                            {{ old('supplier_id', $invoice->supplier_id) == $supplier->id ? 'selected' : '' }}>
                                                            {{ $supplier->trade_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <a href="{{ route('SupplierManagement.create') }}" type="button"
                                                    class="btn btn-primary mr-1 mb-1 waves-effect waves-light">
                                                    <i class="fa fa-user-plus"></i>جديد
                                                </a>
                                            </div>
                                        </div>

                                        <!-- كارد رصيد المورد -->
                                        <div class="row" id="supplierBalanceCard" style="{{ $invoice->supplier_id ? 'display: block;' : 'display: none;' }}">
                                            <div class="col-12">
                                                <div class="card" style="background: #E3F2FD; border-radius: 8px; border: 1px solid #BBDEFB;">
                                                    <div class="card-body p-4">
                                                        <div class="row align-items-center">
                                                            <div class="col-8">
                                                                <a href="#" class="text-decoration-none" style="color: inherit;">
                                                                    <h5 class="card-title mb-2" id="supplierName" style="font-weight: 600; color: #333;">
                                                                        {{ $invoice->supplier->trade_name ?? 'اسم المورد' }}
                                                                    </h5>
                                                                    <p class="mb-0" style="color: #666; font-size: 0.9rem;">
                                                                        <i class="fas fa-edit ml-1" style="color: #2196F3;"></i>
                                                                        <span>تعديل البيانات</span>
                                                                    </p>
                                                                </a>
                                                            </div>
                                                            <div class="col-4 text-left">
                                                                <div class="d-flex flex-column align-items-end">
                                                                    <span style="font-size: 1.8rem; font-weight: 700; color: #333;" id="supplierBalance">
                                                                        {{ number_format(abs($invoice->supplier->account->balance ?? 0), 2) }}
                                                                    </span>
                                                                    <small style="color: #666; margin-top: -5px;">ر.س SAR</small>
                                                                    <span id="balanceStatus" style="font-size: 0.8rem; margin-top: 5px;">
                                                                        {{ ($invoice->supplier->account->balance ?? 0) > 0 ? 'دائن' : (($invoice->supplier->account->balance ?? 0) < 0 ? 'مدين' : 'متوازن') }}
                                                                    </span>
                                                                    <div style="width: 4px; height: 40px; background: #4CAF50; border-radius: 2px; margin-top: 10px;"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="row add_item">
                                    <div class="col-12">
                                        <div class="form-group row">
                                            <div class="col-md-3">
                                                <span>رقم الفاتورة :</span>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="invoice_number"
                                                    value="{{ old('invoice_number', $invoice->invoice_number) }}" readonly>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-group row">
                                            <div class="col-md-3">
                                                <span>التاريخ:</span>
                                            </div>
                                            <div class="col-md-8">
                                                <input class="form-control" type="date" name="date"
                                                    value="{{ old('date', $invoice->date) }}">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-group row">
                                            <div class="col-md-3">
                                                <span>شروط الدفع :</span>
                                            </div>
                                            <div class="col-md-6">
                                                <input class="form-control" type="text" name="terms"
                                                    value="{{ old('terms', $invoice->terms) }}">
                                            </div>
                                            <div class="col-md-2">
                                                <span class="form-control-plaintext">أيام</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-group row">
                                            <div class="col-md-3">
                                                <input class="form-control" type="text" placeholder="عنوان إضافي"
                                                    value="{{ old('additional_title', $invoice->additional_title ?? '') }}">
                                            </div>
                                            <div class="col-md-8">
                                                <div class="input-group">
                                                    <input class="form-control" type="text" placeholder="بيانات إضافية"
                                                        value="{{ old('additional_data', $invoice->additional_data ?? '') }}">
                                                    <div class="input-group-append">
                                                        <button type="button" class="btn btn-outline-success waves-effect waves-light addeventmore">
                                                            <i class="fa fa-plus-circle"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <input type="hidden" id="products-data" value="{{ json_encode($items) }}">
                        <div class="table-responsive">
                            <table class="table" id="items-table">
                                <thead>
                                    <tr>
                                        <th>المنتج</th>
                                        <th>الوصف</th>
                                        <th>الكمية</th>
                                        <th>السعر</th>
                                        <th>الخصم</th>
                                        <th>الضريبة 1</th>
                                        <th>الضريبة 2</th>
                                        <th>المجموع</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if($invoice->items && $invoice->items->count() > 0)
                                        @foreach($invoice->items as $index => $invoiceItem)
                                            <tr class="item-row">
                                                <td style="width:18%">
                                                    <select name="items[{{ $index }}][product_id]" class="form-control product-select select2">
                                                        <option value="">اختر المنتج</option>
                                                        @foreach ($items as $item)
                                                            <option value="{{ $item->id }}" data-price="{{ $item->price }}"
                                                                {{ old("items.{$index}.product_id", $invoiceItem->product_id) == $item->id ? 'selected' : '' }}>
                                                                {{ $item->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" name="items[{{ $index }}][description]" class="form-control item-description"
                                                        value="{{ old("items.{$index}.description", $invoiceItem->description) }}">
                                                </td>
                                                <td>
                                                    <input type="number" name="items[{{ $index }}][quantity]" class="form-control quantity"
                                                        value="{{ old("items.{$index}.quantity", $invoiceItem->quantity) }}" min="1" required>
                                                </td>
                                                <td>
                                                    <input type="number" name="items[{{ $index }}][unit_price]" class="form-control price"
                                                        step="0.01" value="{{ old("items.{$index}.unit_price", $invoiceItem->unit_price) }}" required>
                                                </td>
                                                <td>
                                                    <div class="input-group">
                                                        <input type="number" name="items[{{ $index }}][discount]" class="form-control discount-amount"
                                                            value="{{ old("items.{$index}.discount", $invoiceItem->discount_type == 'amount' ? $invoiceItem->discount : 0) }}"
                                                            min="0" step="0.01"
                                                            style="{{ old("items.{$index}.discount_type", $invoiceItem->discount_type) == 'percentage' ? 'display: none;' : '' }}">
                                                        <input type="number" name="items[{{ $index }}][discount_percentage]" class="form-control discount-percentage"
                                                            value="{{ old("items.{$index}.discount_percentage", $invoiceItem->discount_type == 'percentage' ? $invoiceItem->discount : 0) }}"
                                                            min="0" max="100" step="0.01"
                                                            style="{{ old("items.{$index}.discount_type", $invoiceItem->discount_type) == 'amount' ? 'display: none;' : '' }}">
                                                        <div class="input-group-append">
                                                            <select name="items[{{ $index }}][discount_type]" class="form-control discount-type">
                                                                <option value="amount" {{ old("items.{$index}.discount_type", $invoiceItem->discount_type) == 'amount' ? 'selected' : '' }}>ريال</option>
                                                                <option value="percentage" {{ old("items.{$index}.discount_type", $invoiceItem->discount_type) == 'percentage' ? 'selected' : '' }}>%</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td data-label="الضريبة 1">
                                                    <div class="input-group">
                                                        <select name="items[{{ $index }}][tax_1]" class="form-control tax-select" data-target="tax_1"
                                                            style="width: 150px;" onchange="updateHiddenInput(this)">
                                                            <option value=""></option>
                                                            @foreach ($taxs as $tax)
                                                                <option value="{{ $tax->tax }}" data-id="{{ $tax->id }}"
                                                                    data-name="{{ $tax->name }}" data-type="{{ $tax->type }}"
                                                                    {{ old("items.{$index}.tax_1", $invoiceItem->tax_1) == $tax->tax ? 'selected' : '' }}>
                                                                    {{ $tax->name }}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                        <input type="hidden" name="items[{{ $index }}][tax_1_id]"
                                                            value="{{ old("items.{$index}.tax_1_id", $invoiceItem->tax_1_id) }}">
                                                    </div>
                                                </td>

                                                <td data-label="الضريبة 2">
                                                    <div class="input-group">
                                                        <select name="items[{{ $index }}][tax_2]" class="form-control tax-select" data-target="tax_2"
                                                            style="width: 150px;" onchange="updateHiddenInput(this)">
                                                            <option value=""></option>
                                                            @foreach ($taxs as $tax)
                                                                <option value="{{ $tax->tax }}" data-id="{{ $tax->id }}"
                                                                    data-name="{{ $tax->name }}" data-type="{{ $tax->type }}"
                                                                    {{ old("items.{$index}.tax_2", $invoiceItem->tax_2) == $tax->tax ? 'selected' : '' }}>
                                                                    {{ $tax->name }}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                        <input type="hidden" name="items[{{ $index }}][tax_2_id]"
                                                            value="{{ old("items.{$index}.tax_2_id", $invoiceItem->tax_2_id) }}">
                                                    </div>
                                                </td>

                                                <td>
                                                    <span class="row-total">{{ number_format($invoiceItem->total, 2) }}</span>
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-danger btn-sm remove-row">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr class="item-row">
                                            <td style="width:18%">
                                                <select name="items[0][product_id]" class="form-control product-select select2">
                                                    <option value="">اختر المنتج</option>
                                                    @foreach ($items as $item)
                                                        <option value="{{ $item->id }}" data-price="{{ $item->price }}">
                                                            {{ $item->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td>
                                                <input type="text" name="items[0][description]" class="form-control item-description">
                                            </td>
                                            <td>
                                                <input type="number" name="items[0][quantity]" class="form-control quantity"
                                                    value="1" min="1" required>
                                            </td>
                                            <td>
                                                <input type="number" name="items[0][unit_price]" class="form-control price"
                                                    step="0.01" value="0" required>
                                            </td>
                                            <td>
                                                <div class="input-group">
                                                    <input type="number" name="items[0][discount]" class="form-control discount-amount"
                                                        value="0" min="0" step="0.01">
                                                    <input type="number" name="items[0][discount_percentage]" class="form-control discount-percentage"
                                                        value="0" min="0" max="100" step="0.01" style="display: none;">
                                                    <div class="input-group-append">
                                                        <select name="items[0][discount_type]" class="form-control discount-type">
                                                            <option value="amount">ريال</option>
                                                            <option value="percentage">%</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </td>
                                            <td data-label="الضريبة 1">
                                                <div class="input-group">
                                                    <select name="items[0][tax_1]" class="form-control tax-select" data-target="tax_1"
                                                        style="width: 150px;" onchange="updateHiddenInput(this)">
                                                        <option value=""></option>
                                                        @foreach ($taxs as $tax)
                                                            <option value="{{ $tax->tax }}" data-id="{{ $tax->id }}"
                                                                data-name="{{ $tax->name }}" data-type="{{ $tax->type }}">
                                                                {{ $tax->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                    <input type="hidden" name="items[0][tax_1_id]">
                                                </div>
                                            </td>

                                            <td data-label="الضريبة 2">
                                                <div class="input-group">
                                                    <select name="items[0][tax_2]" class="form-control tax-select" data-target="tax_2"
                                                        style="width: 150px;" onchange="updateHiddenInput(this)">
                                                        <option value=""></option>
                                                        @foreach ($taxs as $tax)
                                                            <option value="{{ $tax->tax }}" data-id="{{ $tax->id }}"
                                                                data-name="{{ $tax->name }}" data-type="{{ $tax->type }}">
                                                                {{ $tax->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                    <input type="hidden" name="items[0][tax_2_id]">
                                                </div>
                                            </td>

                                            <td>
                                                <span class="row-total">0.00</span>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-danger btn-sm remove-row">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    @endif
                                </tbody>
                                <tfoot id="tax-rows">
                                    <tr>
                                        <td colspan="9" class="text-right">
                                            <button type="button" id="add-row" class="btn btn-success">
                                                <i class="fa fa-plus"></i> إضافة صف
                                            </button>
                                        </td>
                                    </tr>
                                    @php
                                        $currency = $account_setting->currency ?? 'SAR';
                                        $currencySymbol = $currency == 'SAR' || empty($currency) ?
                                            '<img src="' . asset('assets/images/Saudi_Riyal.svg') . '" alt="ريال سعودي" width="13" style="display: inline-block; margin-left: 5px; vertical-align: middle;">' :
                                            $currency;
                                    @endphp
                                    <tr>
                                        <td colspan="7" class="text-right">المجموع الفرعي</td>
                                        <td><span id="subtotal">{{ number_format($invoice->subtotal ?? 0, 2) }}</span> {!! $currencySymbol !!}</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td colspan="7" class="text-right">مجموع الخصومات</td>
                                        <td><span id="total-discount">{{ number_format($invoice->discount_amount ?? 0, 2) }}</span> {!! $currencySymbol !!}</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <small id="tax-details"></small>
                                    </tr>
                                    <tr>
                                        <td colspan="7" class="text-right">تكلفة الشحن</td>
                                        <td><span id="shipping-cost">{{ number_format($invoice->shipping_cost ?? 0, 2) }}</span> {!! $currencySymbol !!}</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td colspan="7" class="text-right">الدفعة المقدمة</td>
                                        <td><span id="advance-payment">{{ number_format($invoice->advance_payment ?? 0, 2) }}</span> {!! $currencySymbol !!}</td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td colspan="7" class="text-right">المجموع الكلي</td>
                                        <td><span id="grand-total">{{ number_format($invoice->total ?? 0, 2) }}</span> {!! $currencySymbol !!}</td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header bg-white">
                    <ul class="nav nav-tabs card-header-tabs align-items-center">
                        <li class="nav-item">
                            <a class="nav-link active" id="tab-discount" href="#">الخصم والتسوية</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="tab-deposit" href="#">إيداع</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="tab-shipping" href="#">التوصيل</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="tab-documents" href="#">إرفاق المستندات</a>
                        </li>
                    </ul>
                </div>

                <div class="card-body">
                    <!-- القسم الأول: الخصم والتسوية -->
                    <div id="section-discount" class="tab-section">
                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label">قيمة الخصم</label>
                                <div class="input-group">
                                    <input type="number" name="discount_amount" class="form-control"
                                        value="{{ old('discount_amount', $invoice->discount_amount ?? 0) }}"
                                        min="0" step="0.01">
                                    <select name="discount_type" class="form-control">
                                        <option value="amount" {{ old('discount_type', $invoice->discount_type) == 'amount' ? 'selected' : '' }}>ريال</option>
                                        <option value="percentage" {{ old('discount_type', $invoice->discount_type) == 'percentage' ? 'selected' : '' }}>نسبة مئوية</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">التسوية</label>
                                <div class="input-group">
                                    <input type="text" name="adjustment_label" class="form-control"
                                        placeholder="اسم التسوية (مثال: خصم نقدي)"
                                        value="{{ old('adjustment_label', $invoice->adjustment_label) }}">
                                    <select name="adjustment_type" class="form-control">
                                        <option value="discount" {{ old('adjustment_type', $invoice->adjustment_type) == 'discount' ? 'selected' : '' }}>خصم</option>
                                        <option value="addition" {{ old('adjustment_type', $invoice->adjustment_type) == 'addition' ? 'selected' : '' }}>إضافة</option>
                                    </select>
                                    <input type="number" name="adjustment_value" step="0.01" class="form-control"
                                        placeholder="قيمة التسوية" value="{{ old('adjustment_value', $invoice->adjustment_value ?? 0) }}">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- القسم الثاني: الإيداع -->
                    <div id="section-deposit" class="tab-section d-none">
                        <div class="row">
                            <div class="col-md-3">
                                <label class="form-label">الدفعة المقدمة</label>
                                <div class="input-group">
                                    <input type="number" id="advanced-payment" class="form-control"
                                        value="{{ old('advance_payment', $invoice->advance_payment ?? 0) }}"
                                        name="advance_payment" step="0.01" min="0" placeholder="الدفعة المقدمة">
                                    <select name="advance_payment_type" class="form-control">
                                        <option value="amount" {{ old('advance_payment_type', $invoice->advance_payment_type) == 'amount' ? 'selected' : '' }}>ريال</option>
                                        <option value="percentage" {{ old('advance_payment_type', $invoice->advance_payment_type) == 'percentage' ? 'selected' : '' }}>نسبة مئوية</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="card mt-3">
                            <div class="card-body py-2 align-items-right">
                                <div class="d-flex justify-content-start" style="direction: rtl;">
                                    <div class="form-check">
                                        <input class="form-check-input toggle-check" type="checkbox" name="is_advance_paid" value="1"
                                            {{ old('is_advance_paid', $invoice->is_advance_paid) ? 'checked' : '' }}>
                                        <label class="form-check-label">مدفوع بالفعل</label>
                                    </div>
                                </div>

                                <div class="payment-fields mt-3" style="{{ old('is_advance_paid', $invoice->is_advance_paid) ? 'display: block;' : 'display: none;' }}">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="advance_payment_method">وسيلة الدفع</label>
                                            <select class="form-control" name="advance_payment_method">
                                                <option value="">اختر وسيلة الدفع</option>
                                                <option value="cash" {{ old('advance_payment_method', $invoice->advance_payment_method) == 'cash' ? 'selected' : '' }}>نقداً</option>
                                                <option value="credit_card" {{ old('advance_payment_method', $invoice->advance_payment_method) == 'credit_card' ? 'selected' : '' }}>بطاقة ائتمان</option>
                                                <option value="bank_transfer" {{ old('advance_payment_method', $invoice->advance_payment_method) == 'bank_transfer' ? 'selected' : '' }}>تحويل بنكي</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">رقم المعرف</label>
                                            <input type="text" class="form-control" name="advance_reference_number"
                                                value="{{ old('advance_reference_number', $invoice->advance_reference_number) }}">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- القسم الثالث: التوصيل -->
                    <div id="section-shipping" class="tab-section d-none">
                        <div class="row">
                            <div class="col-md-3">
                                <label class="form-label">نوع الضريبة</label>
                                <select class="form-control" id="methodSelect" name="shipping_tax_id">
                                    <option value="">اختر الضريبة</option>
                                    @foreach ($taxs as $tax)
                                        <option value="{{ $tax->id }}" data-rate="{{ $tax->tax }}"
                                            {{ old('shipping_tax_id', $invoice->shipping_tax_id) == $tax->id ? 'selected' : '' }}>
                                            {{ $tax->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">تكلفة الشحن</label>
                                <input type="number" class="form-control" name="shipping_cost" id="shipping"
                                    value="{{ old('shipping_cost', $invoice->shipping_cost ?? 0) }}" min="0" step="0.01">
                            </div>
                        </div>
                    </div>

                    <!-- القسم الرابع: إرفاق المستندات -->
                    <div id="section-documents" class="tab-section d-none">
                        <ul class="nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" id="tab-new-document" href="#">رفع مستند جديد</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-uploaded-documents" href="#">بحث في الملفات</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-existing-documents" href="#">المستندات الحالية</a>
                            </li>
                        </ul>

                        <div class="tab-content mt-3">
                            <div id="content-new-document" class="tab-pane active">
                                <div class="col-12 mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-file-upload text-primary me-2"></i>
                                        رفع مستند جديد:
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-primary text-white">
                                            <i class="fas fa-upload"></i>
                                        </span>
                                        <input type="file" class="form-control" id="uploadFile"
                                            aria-describedby="uploadButton" name="attachments[]" multiple>
                                        <button class="btn btn-primary" type="button" id="uploadButton">
                                            <i class="fas fa-cloud-upload-alt me-1"></i>
                                            رفع
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div id="content-uploaded-documents" class="tab-pane d-none">
                                <div class="row">
                                    <div class="col-12 mb-3">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center gap-2" style="width: 80%;">
                                                <label class="form-label mb-0" style="white-space: nowrap;">المستند:</label>
                                                <select class="form-select">
                                                    <option selected>اختر مستند</option>
                                                    <option value="1">مستند 1</option>
                                                    <option value="2">مستند 2</option>
                                                    <option value="3">مستند 3</option>
                                                </select>
                                                <button type="button" class="btn btn-success">أرفق</button>
                                            </div>
                                            <button type="button" class="btn btn-primary">
                                                <i class="fas fa-search me-1"></i>
                                                بحث متقدم
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="content-existing-documents" class="tab-pane d-none">
                                @if($invoice->attachments && $invoice->attachments->count() > 0)
                                    <div class="row">
                                        @foreach($invoice->attachments as $attachment)
                                            <div class="col-md-4 mb-3">
                                                <div class="card">
                                                    <div class="card-body text-center">
                                                        <i class="fas fa-file-alt fa-3x text-primary mb-2"></i>
                                                        <h6 class="card-title">{{ $attachment->original_name }}</h6>
                                                        <p class="card-text small text-muted">
                                                            {{ $attachment->size ? number_format($attachment->size / 1024, 2) : '0' }} KB
                                                        </p>
                                                        <div class="btn-group btn-group-sm">
                                                            <a href="{{ route('invoices.download-attachment', $attachment->id) }}"
                                                               class="btn btn-outline-primary">
                                                                <i class="fas fa-download"></i> تحميل
                                                            </a>
                                                            <button type="button" class="btn btn-outline-danger"
                                                                onclick="deleteAttachment({{ $attachment->id }})">
                                                                <i class="fas fa-trash"></i> حذف
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                @else
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle"></i>
                                        لا توجد مستندات مرفقة حالياً
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0">
                <div class="card-header border-bottom" style="background-color: transparent;">
                    <h5 class="mb-0 fw-bold text-dark" style="font-size: 1.2rem;">
                        📝 الملاحظات / الشروط
                    </h5>
                </div>
                <div class="card-body">
                    <textarea id="tinyMCE" name="notes" class="form-control" rows="6"
                        style="font-size: 1.05rem;">{{ old('notes', $invoice->notes) }}</textarea>
                </div>
            </div>

            <div class="card">
                <div class="card-body py-2 align-items-right">
                    <div class="d-flex justify-content-start" style="direction: rtl;">
                        <div class="form-check">
                            <input class="form-check-input toggle-check" type="checkbox" name="is_paid" value="1"
                                {{ old('is_paid', $invoice->is_paid) ? 'checked' : '' }}>
                            <label class="form-check-label">تم الدفع بالفعل إلى المورد؟</label>
                        </div>
                    </div>

                    <div class="payment-fields mt-3" style="{{ old('is_paid', $invoice->is_paid) ? 'display: block;' : 'display: none;' }}">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="payment_method">وسيلة الدفع</label>
                                <select class="form-control" name="payment_method">
                                    <option value="">اختر وسيلة الدفع</option>
                                    <option value="cash" {{ old('payment_method', $invoice->payment_method) == 'cash' ? 'selected' : '' }}>نقداً</option>
                                    <option value="credit_card" {{ old('payment_method', $invoice->payment_method) == 'credit_card' ? 'selected' : '' }}>بطاقة ائتمان</option>
                                    <option value="bank_transfer" {{ old('payment_method', $invoice->payment_method) == 'bank_transfer' ? 'selected' : '' }}>تحويل بنكي</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">رقم المعرف</label>
                                <input type="text" class="form-control" name="reference_number"
                                    value="{{ old('reference_number', $invoice->reference_number) }}">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body py-2 align-items-right">
                    <div class="d-flex justify-content-start" style="direction: rtl;">
                        <div class="form-check">
                            <input class="form-check-input toggle-check" type="checkbox" name="is_received" value="1"
                                {{ old('is_received', $invoice->is_received) ? 'checked' : '' }}>
                            <label class="form-check-label">مستلم</label>
                        </div>
                    </div>

                    <div class="payment-fields mt-3" style="{{ old('is_received', $invoice->is_received) ? 'display: block;' : 'display: none;' }}">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="form-label">تاريخ الاستلام</label>
                                <input type="date" class="form-control" name="received_date"
                                    value="{{ old('received_date', $invoice->received_date ? $invoice->received_date->format('Y-m-d') : '') }}">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- قسم سجل التعديلات -->
            @if($invoice->revisions && $invoice->revisions->count() > 0)
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-history"></i>
                            سجل التعديلات
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="timeline">
                            @foreach($invoice->revisions as $revision)
                                <div class="timeline-item">
                                    <div class="timeline-marker"></div>
                                    <div class="timeline-content">
                                        <h6 class="timeline-title">{{ $revision->user->name ?? 'مستخدم غير معروف' }}</h6>
                                        <p class="timeline-text">
                                            تم تعديل الفاتورة في {{ $revision->created_at->format('d/m/Y H:i') }}
                                        </p>
                                        @if($revision->old_values)
                                            <small class="text-muted">
                                                التغييرات: {{ implode(', ', array_keys($revision->old_values)) }}
                                            </small>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif
        </form>
    </div>
@endsection

@section('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="{{ asset('assets/js/invoice.js') }}"></script>

    <script>
        // متغيرات خاصة بصفحة التعديل
        const invoiceId = {{ $invoice->id }};
        const isEditMode = true;

        // وظائف إدارة التبويبات والحقول
        document.querySelectorAll('.toggle-check').forEach((checkbox) => {
            checkbox.addEventListener('change', function() {
                const paymentFields = this.closest('.card-body').querySelector('.payment-fields');
                if (this.checked) {
                    paymentFields.style.display = 'block';
                } else {
                    paymentFields.style.display = 'none';
                }
            });
        });

        // تحديث الحقول المخفية للضرائب
        function updateHiddenInput(selectElement) {
            var row = selectElement.closest('.item-row');
            var taxType = selectElement.getAttribute('data-target');
            var hiddenInput = row.querySelector('input[name^="items"][name$="[' + taxType + '_id]"]');

            if (hiddenInput) {
                hiddenInput.value = selectElement.options[selectElement.selectedIndex].getAttribute('data-id');
            }
        }

        // وظيفة تكرار الفاتورة
        function duplicateInvoice() {
            Swal.fire({
                title: 'تكرار الفاتورة',
                text: 'هل تريد إنشاء فاتورة جديدة بنفس البيانات؟',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'نعم، كرر',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = ``;
                }
            });
        }

        // وظيفة حذف الفاتورة
        function deleteInvoice() {
            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: 'سيتم حذف الفاتورة نهائياً ولا يمكن استرجاعها!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف!',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    // إنشاء نموذج للحذف
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = `{{ route('invoicePurchases.destroy', $invoice->id) }}`;

                    const csrfToken = document.createElement('input');
                    csrfToken.type = 'hidden';
                    csrfToken.name = '_token';
                    csrfToken.value = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                    const methodField = document.createElement('input');
                    methodField.type = 'hidden';
                    methodField.name = '_method';
                    methodField.value = 'DELETE';

                    form.appendChild(csrfToken);
                    form.appendChild(methodField);
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        }

        // وظيفة حذف المرفق
        function deleteAttachment(attachmentId) {
            Swal.fire({
                title: 'حذف المرفق',
                text: 'هل تريد حذف هذا المرفق؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`/invoices/attachments/${attachmentId}`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                            'Content-Type': 'application/json'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'تم الحذف',
                                text: 'تم حذف المرفق بنجاح',
                                icon: 'success',
                                timer: 1500,
                                showConfirmButton: false
                            });

                            // إعادة تحميل قسم المستندات
                            location.reload();
                        } else {
                            Swal.fire({
                                title: 'خطأ',
                                text: 'حدث خطأ أثناء حذف المرفق',
                                icon: 'error',
                                confirmButtonText: 'حسناً'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'خطأ',
                            text: 'حدث خطأ أثناء حذف المرفق',
                            icon: 'error',
                            confirmButtonText: 'حسناً'
                        });
                    });
                }
            });
        }

        // حساب الإجماليات المحسن (نفس الوظيفة من صفحة الإنشاء)
        document.addEventListener("DOMContentLoaded", function() {
            function calculateTotals() {
                let subtotal = 0;
                let totalItemDiscount = 0;
                let totalItemTax = 0;
                let taxDetails = {};

                // مسح الصفوف الديناميكية السابقة
                document.querySelectorAll(".dynamic-tax-row").forEach(row => row.remove());

                // حساب كل صف من العناصر
                document.querySelectorAll(".item-row").forEach(function(row) {
                    let quantity = parseFloat(row.querySelector(".quantity").value) || 0;
                    let unitPrice = parseFloat(row.querySelector(".price").value) || 0;
                    let itemSubtotal = quantity * unitPrice;
                    subtotal += itemSubtotal;

                    // حساب خصم العنصر
                    let itemDiscount = 0;
                    let discountType = row.querySelector(".discount-type").value;
                    if (discountType === 'percentage') {
                        let discountPercentage = parseFloat(row.querySelector(".discount-percentage").value) || 0;
                        itemDiscount = (itemSubtotal * discountPercentage) / 100;
                    } else {
                        itemDiscount = parseFloat(row.querySelector(".discount-amount").value) || 0;
                    }
                    totalItemDiscount += itemDiscount;

                    // حساب الضرائب
                    let tax1Value = parseFloat(row.querySelector("[name^='items'][name$='[tax_1]']").value) || 0;
                    let tax1Type = row.querySelector("[name^='items'][name$='[tax_1]']").options[
                        row.querySelector("[name^='items'][name$='[tax_1]']").selectedIndex
                    ].dataset.type;
                    let tax1Name = row.querySelector("[name^='items'][name$='[tax_1]']").options[
                        row.querySelector("[name^='items'][name$='[tax_1]']").selectedIndex
                    ].dataset.name;

                    let tax2Value = parseFloat(row.querySelector("[name^='items'][name$='[tax_2]']").value) || 0;
                    let tax2Type = row.querySelector("[name^='items'][name$='[tax_2]']").options[
                        row.querySelector("[name^='items'][name$='[tax_2]']").selectedIndex
                    ].dataset.type;
                    let tax2Name = row.querySelector("[name^='items'][name$='[tax_2]']").options[
                        row.querySelector("[name^='items'][name$='[tax_2]']").selectedIndex
                    ].dataset.name;

                    // حساب الضريبة الأولى
                    if (tax1Value > 0 && tax1Name) {
                        let itemTax = 0;
                        if (tax1Type === 'included') {
                            itemTax = itemSubtotal - (itemSubtotal / (1 + (tax1Value / 100)));
                        } else {
                            itemTax = (itemSubtotal * tax1Value) / 100;
                        }

                        if (!taxDetails[tax1Name]) {
                            taxDetails[tax1Name] = 0;
                        }
                        taxDetails[tax1Name] += itemTax;
                        totalItemTax += itemTax;
                    }

                    // حساب الضريبة الثانية
                    if (tax2Value > 0 && tax2Name) {
                        let itemTax = 0;
                        if (tax2Type === 'included') {
                            itemTax = itemSubtotal - (itemSubtotal / (1 + (tax2Value / 100)));
                        } else {
                            itemTax = (itemSubtotal * tax2Value) / 100;
                        }

                        if (!taxDetails[tax2Name]) {
                            taxDetails[tax2Name] = 0;
                        }
                        taxDetails[tax2Name] += itemTax;
                        totalItemTax += itemTax;
                    }

                    // تحديث إجمالي الصف
                    let rowTotal = itemSubtotal - itemDiscount;
                    row.querySelector(".row-total").innerText = rowTotal.toFixed(2);
                });

                // حساب الخصم الإضافي
                let additionalDiscount = 0;
                let discountAmount = parseFloat(document.querySelector("[name='discount_amount']")?.value) || 0;
                let discountType = document.querySelector("[name='discount_type']")?.value;

                if (discountAmount > 0) {
                    if (discountType === 'percentage') {
                        additionalDiscount = (subtotal * discountAmount) / 100;
                    } else {
                        additionalDiscount = discountAmount;
                    }
                }

                // حساب التسوية
                let adjustmentAmount = 0;
                let adjustmentValue = parseFloat(document.querySelector("[name='adjustment_value']")?.value) || 0;
                let adjustmentType = document.querySelector("[name='adjustment_type']")?.value;

                if (adjustmentValue > 0) {
                    if (adjustmentType === 'discount') {
                        adjustmentAmount = -adjustmentValue;
                    } else {
                        adjustmentAmount = adjustmentValue;
                    }
                }

                // حساب الدفعة المقدمة
                let advancePayment = 0;
                let advanceAmount = parseFloat(document.querySelector("[name='advance_payment']")?.value) || 0;
                let advanceType = document.querySelector("[name='advance_payment_type']")?.value;

                if (advanceAmount > 0) {
                    if (advanceType === 'percentage') {
                        advancePayment = (subtotal * advanceAmount) / 100;
                    } else {
                        advancePayment = advanceAmount;
                    }
                }

                // حساب تكلفة الشحن وضريبتها
                let shippingCost = parseFloat(document.querySelector("[name='shipping_cost']")?.value) || 0;
                let shippingTax = 0;
                let shippingTaxSelect = document.querySelector("[name='shipping_tax_id']");

                if (shippingCost > 0 && shippingTaxSelect && shippingTaxSelect.value) {
                    let selectedOption = shippingTaxSelect.options[shippingTaxSelect.selectedIndex];
                    let taxRate = parseFloat(selectedOption.dataset.rate) || 0;
                    let taxName = selectedOption.text;

                    if (taxRate > 0) {
                        shippingTax = (shippingCost * taxRate) / 100;
                        let shippingTaxName = taxName + " (شحن)";
                        if (!taxDetails[shippingTaxName]) {
                            taxDetails[shippingTaxName] = 0;
                        }
                        taxDetails[shippingTaxName] += shippingTax;
                    }
                }

                // إضافة الصفوف الديناميكية
                let taxRowsContainer = document.getElementById("tax-rows");

                // إضافة صف الخصم الإضافي
                if (additionalDiscount > 0) {
                    let discountRow = document.createElement("tr");
                    discountRow.classList.add("dynamic-tax-row");
                    discountRow.innerHTML = `
                        <td colspan="7" class="text-right">خصم إضافي</td>
                        <td><span class="text-danger">-${additionalDiscount.toFixed(2)}</span></td>
                        <td></td>
                    `;
                    taxRowsContainer.insertBefore(discountRow, document.querySelector("#tax-rows tr:last-child"));
                }

                // إضافة صف التسوية
                if (adjustmentAmount !== 0) {
                    let adjustmentLabel = document.querySelector("[name='adjustment_label']")?.value || "تسوية";
                    let adjustmentRow = document.createElement("tr");
                    adjustmentRow.classList.add("dynamic-tax-row");
                    let adjustmentClass = adjustmentAmount > 0 ? "text-success" : "text-danger";
                    let adjustmentSign = adjustmentAmount > 0 ? "+" : "";

                    adjustmentRow.innerHTML = `
                        <td colspan="7" class="text-right">${adjustmentLabel}</td>
                        <td><span class="${adjustmentClass}">${adjustmentSign}${adjustmentAmount.toFixed(2)}</span></td>
                        <td></td>
                    `;
                    taxRowsContainer.insertBefore(adjustmentRow, document.querySelector("#tax-rows tr:last-child"));
                }

                // إضافة صفوف الضرائب
                for (let taxName in taxDetails) {
                    let taxRow = document.createElement("tr");
                    taxRow.classList.add("dynamic-tax-row");
                    taxRow.innerHTML = `
                        <td colspan="7" class="text-right">${taxName}</td>
                        <td><span>${taxDetails[taxName].toFixed(2)}</span></td>
                        <td></td>
                    `;
                    taxRowsContainer.insertBefore(taxRow, document.querySelector("#tax-rows tr:last-child"));
                }

                // تحديث القيم النهائية
                let totalDiscount = totalItemDiscount + additionalDiscount;
                let totalTax = totalItemTax + shippingTax;
                let grandTotal = subtotal - totalDiscount + adjustmentAmount + shippingCost + totalTax;

                document.getElementById("subtotal").innerText = subtotal.toFixed(2);
                document.getElementById("total-discount").innerText = totalDiscount.toFixed(2);
                document.getElementById("shipping-cost").innerText = shippingCost.toFixed(2);
                document.getElementById("advance-payment").innerText = advancePayment.toFixed(2);
                document.getElementById("grand-total").innerText = grandTotal.toFixed(2);
            }

            // ربط أحداث الحساب
            document.addEventListener("input", function(event) {
                if (event.target.matches(
                    ".quantity, .price, .discount-amount, .discount-percentage, [name='discount_amount'], [name='adjustment_value'], [name='advance_payment'], [name='shipping_cost']"
                )) {
                    calculateTotals();
                }
            });

            document.addEventListener("change", function(event) {
                if (event.target.matches(
                    ".tax-select, .discount-type, [name='discount_type'], [name='adjustment_type'], [name='advance_payment_type'], [name='shipping_tax_id']"
                )) {
                    calculateTotals();
                }
            });

            calculateTotals();
        });

        // إدارة إضافة وحذف الصفوف
        document.addEventListener('click', function(e) {
            if (e.target.closest('#add-row')) {
                e.preventDefault();
                addNewRow();
            }

            if (e.target.closest('.remove-row')) {
                e.preventDefault();
                removeRow(e.target.closest('.item-row'));
            }
        });

        function addNewRow() {
            let table = document.querySelector('#items-table tbody');
            let rowCount = table.children.length;
            let newRow = table.children[0].cloneNode(true);

            newRow.querySelectorAll('input, select').forEach(function(input) {
                if (input.name) {
                    input.name = input.name.replace(/\[\d+\]/, `[${rowCount}]`);
                    if (input.type !== 'hidden') {
                        input.value = input.type === 'number' ? (input.classList.contains('quantity') ? '1' : '0') : '';
                    }
                }
            });

            // إعادة تهيئة Select2 للصف الجديد
            $(newRow).find('.select2').removeClass('select2-hidden-accessible').next().remove().end().select2();

            table.appendChild(newRow);
            calculateTotals();
        }

        function removeRow(row) {
            if (document.querySelectorAll('.item-row').length > 1) {
                row.remove();
                calculateTotals();
            } else {
                Swal.fire({
                    title: 'تنبيه',
                    text: 'لا يمكن حذف جميع العناصر',
                    icon: 'warning',
                    confirmButtonText: 'حسناً'
                });
            }
        }

        // إدارة التبويبات الرئيسية
        document.addEventListener('click', function(e) {
            if (e.target.matches('#tab-discount, #tab-deposit, #tab-shipping, #tab-documents')) {
                e.preventDefault();

                // إزالة الفئة النشطة من جميع التبويبات
                document.querySelectorAll('.nav-link').forEach(tab => tab.classList.remove('active'));
                document.querySelectorAll('.tab-section').forEach(section => section.classList.add('d-none'));

                // إضافة الفئة النشطة للتبويب المحدد
                e.target.classList.add('active');

                // إظهار القسم المقابل
                let targetSection = '';
                switch (e.target.id) {
                    case 'tab-discount':
                        targetSection = 'section-discount';
                        break;
                    case 'tab-deposit':
                        targetSection = 'section-deposit';
                        break;
                    case 'tab-shipping':
                        targetSection = 'section-shipping';
                        break;
                    case 'tab-documents':
                        targetSection = 'section-documents';
                        break;
                }

                if (targetSection) {
                    document.getElementById(targetSection).classList.remove('d-none');
                }
            }

            // إدارة التبويبات الفرعية للمستندات
            if (e.target.matches('#tab-new-document, #tab-uploaded-documents, #tab-existing-documents')) {
                e.preventDefault();

                document.querySelectorAll('#tab-new-document, #tab-uploaded-documents, #tab-existing-documents').forEach(tab =>
                    tab.classList.remove('active'));
                document.querySelectorAll('#content-new-document, #content-uploaded-documents, #content-existing-documents').forEach(content =>
                    content.classList.add('d-none'));

                e.target.classList.add('active');

                if (e.target.id === 'tab-new-document') {
                    document.getElementById('content-new-document').classList.remove('d-none');
                } else if (e.target.id === 'tab-uploaded-documents') {
                    document.getElementById('content-uploaded-documents').classList.remove('d-none');
                } else if (e.target.id === 'tab-existing-documents') {
                    document.getElementById('content-existing-documents').classList.remove('d-none');
                }
            }
        });

        // وظيفة عرض رصيد المورد
        function showSupplierBalance(selectElement) {
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            const balanceCard = document.getElementById('supplierBalanceCard');

            if (selectedOption.value && selectedOption.value !== '') {
                balanceCard.style.display = 'block';

                const supplierName = selectedOption.text;
                const supplierBalance = parseFloat(selectedOption.getAttribute('data-balance')) || 0;

                document.getElementById('supplierName').textContent = supplierName;
                document.getElementById('supplierBalance').textContent = Math.abs(supplierBalance).toFixed(2);

                const balanceStatus = document.getElementById('balanceStatus');
                const balanceElement = document.getElementById('supplierBalance');

                if (supplierBalance > 0) {
                    balanceStatus.textContent = 'دائن';
                    balanceStatus.style.color = '#4CAF50';
                    balanceElement.style.color = '#4CAF50';
                } else if (supplierBalance < 0) {
                    balanceStatus.textContent = 'مدين';
                    balanceStatus.style.color = '#f44336';
                    balanceElement.style.color = '#f44336';
                } else {
                    balanceStatus.textContent = 'متوازن';
                    balanceStatus.style.color = '#FFC107';
                    balanceElement.style.color = '#FFC107';
                }

                // تأثير الانيميشن
                balanceCard.style.opacity = '0';
                balanceCard.style.transform = 'translateY(-20px)';

                setTimeout(() => {
                    balanceCard.style.transition = 'all 0.3s ease';
                    balanceCard.style.opacity = '1';
                    balanceCard.style.transform = 'translateY(0)';
                }, 10);

            } else {
                balanceCard.style.display = 'none';
            }
        }

        // إدارة اختيار المنتجات وتحديث الأسعار
        document.addEventListener('change', function(e) {
            if (e.target && e.target.classList.contains('product-select')) {
                let selectedOption = e.target.options[e.target.selectedIndex];
                let price = selectedOption.getAttribute('data-price') || 0;
                let row = e.target.closest('.item-row');
                let priceInput = row.querySelector('.price');

                if (priceInput) {
                    priceInput.value = price;
                    calculateTotals();
                }
            }
        });

        // إدارة نوع الخصم لكل عنصر
        document.addEventListener('change', function(e) {
            if (e.target && e.target.classList.contains('discount-type')) {
                let row = e.target.closest('.item-row');
                let discountAmountInput = row.querySelector('.discount-amount');
                let discountPercentageInput = row.querySelector('.discount-percentage');

                if (e.target.value === 'percentage') {
                    discountAmountInput.style.display = 'none';
                    discountPercentageInput.style.display = 'block';
                } else {
                    discountAmountInput.style.display = 'block';
                    discountPercentageInput.style.display = 'none';
                }
            }
        });

        // وظيفة حفظ كمسودة (معدلة للتعديل)
        function saveAsDraft() {
            let form = document.getElementById('invoice-form');
            let formData = new FormData(form);
            formData.append('is_draft', '1');

            // تغيير الـ method للتحديث
            let methodInput = document.createElement('input');
            methodInput.type = 'hidden';
            methodInput.name = '_method';
            methodInput.value = 'PUT';
            form.appendChild(methodInput);

            fetch(`{{ route('invoicePurchases.update', $invoice->id) }}`, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم الحفظ',
                        text: 'تم حفظ الفاتورة كمسودة بنجاح',
                        icon: 'success',
                        confirmButtonText: 'حسناً'
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ',
                        text: 'حدث خطأ أثناء حفظ المسودة',
                        icon: 'error',
                        confirmButtonText: 'حسناً'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ',
                    text: 'حدث خطأ أثناء حفظ المسودة',
                    icon: 'error',
                    confirmButtonText: 'حسناً'
                });
            });
        }

        // وظيفة إظهار معاينة سريعة للفاتورة
        function showQuickPreview() {
            let subtotal = parseFloat(document.getElementById('subtotal').textContent) || 0;
            let discount = parseFloat(document.getElementById('total-discount').textContent) || 0;
            let total = parseFloat(document.getElementById('grand-total').textContent) || 0;
            let supplier = document.getElementById('clientSelect').options[document.getElementById('clientSelect').selectedIndex].text;

            let itemsCount = document.querySelectorAll('.item-row').length;
            let invoiceStatus = '{{ $invoice->status == "paid" ? "مدفوعة" : ($invoice->status == "draft" ? "مسودة" : "معلقة") }}';

            Swal.fire({
                title: 'معاينة سريعة - فاتورة #{{ $invoice->invoice_number }}',
                html: `
                    <div class="text-right" style="direction: rtl;">
                        <p><strong>الحالة:</strong> <span class="badge badge-{{ $invoice->status == 'paid' ? 'success' : ($invoice->status == 'draft' ? 'secondary' : 'warning') }}">${invoiceStatus}</span></p>
                        <p><strong>المورد:</strong> ${supplier}</p>
                        <p><strong>عدد العناصر:</strong> ${itemsCount}</p>
                        <p><strong>المجموع الفرعي:</strong> ${subtotal.toFixed(2)} ر.س</p>
                        <p><strong>إجمالي الخصومات:</strong> ${discount.toFixed(2)} ر.س</p>
                        <p><strong>المجموع الكلي:</strong> ${total.toFixed(2)} ر.س</p>
                        <p><strong>تاريخ الإنشاء:</strong> {{ $invoice->created_at->format('d/m/Y H:i') }}</p>
                        <p><strong>آخر تعديل:</strong> {{ $invoice->updated_at->format('d/m/Y H:i') }}</p>
                    </div>
                `,
                icon: 'info',
                confirmButtonText: 'إغلاق',
                width: '500px'
            });
        }

        // وظيفة التحقق من صحة البيانات قبل الإرسال
        function validateForm() {
            let isValid = true;
            let errors = [];

            // التحقق من المورد
            let supplier = document.getElementById('clientSelect').value;
            if (!supplier) {
                errors.push('يجب اختيار المورد');
                isValid = false;
            }

            // التحقق من وجود عناصر
            let hasValidItems = false;
            document.querySelectorAll('.item-row').forEach(function(row) {
                let product = row.querySelector('.product-select').value;
                let quantity = row.querySelector('.quantity').value;
                let price = row.querySelector('.price').value;

                if (product && quantity > 0 && price > 0) {
                    hasValidItems = true;
                }
            });

            if (!hasValidItems) {
                errors.push('يجب إضافة عنصر واحد على الأقل صحيح');
                isValid = false;
            }

            if (!isValid) {
                Swal.fire({
                    title: 'خطأ في البيانات',
                    html: errors.join('<br>'),
                    icon: 'error',
                    confirmButtonText: 'حسناً'
                });
            }

            return isValid;
        }

        // التحقق من البيانات قبل الإرسال
        document.getElementById('invoice-form').addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
                return false;
            }

            // إظهار محمل التحميل
            Swal.fire({
                title: 'جاري الحفظ...',
                text: 'يرجى الانتظار',
                allowOutsideClick: false,
                showConfirmButton: false,
                willOpen: () => {
                    Swal.showLoading();
                }
            });
        });

        // وظيفة تصدير الفاتورة كـ PDF
        function exportToPDF() {
            window.open(`{{ route('invoicePurchases.pdf', $invoice->id) }}`, '_blank');
        }

        // وظيفة إرسال الفاتورة بالبريد الإلكتروني
        function sendByEmail() {
            Swal.fire({
                title: 'إرسال بالبريد الإلكتروني',
                html: `
                    <input type="email" id="email-input" class="swal2-input" placeholder="البريد الإلكتروني" value="{{ $invoice->supplier->email ?? '' }}">
                    <textarea id="message-input" class="swal2-textarea" placeholder="رسالة إضافية (اختيارية)"></textarea>
                `,
                showCancelButton: true,
                confirmButtonText: 'إرسال',
                cancelButtonText: 'إلغاء',
                preConfirm: () => {
                    const email = document.getElementById('email-input').value;
                    const message = document.getElementById('message-input').value;

                    if (!email) {
                        Swal.showValidationMessage('يرجى إدخال البريد الإلكتروني');
                        return false;
                    }

                    return { email: email, message: message };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    let formData = new FormData();
                    formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
                    formData.append('email', result.value.email);
                    formData.append('message', result.value.message);

                    fetch(``, {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'تم الإرسال',
                                text: 'تم إرسال الفاتورة بالبريد الإلكتروني بنجاح',
                                icon: 'success',
                                confirmButtonText: 'حسناً'
                            });
                        } else {
                            throw new Error(data.message);
                        }
                    })
                    .catch(error => {
                        Swal.fire({
                            title: 'خطأ',
                            text: 'حدث خطأ أثناء إرسال البريد الإلكتروني',
                            icon: 'error',
                            confirmButtonText: 'حسناً'
                        });
                    });
                }
            });
        }

        // وظيفة طباعة الفاتورة
        function printInvoice() {
            window.open(``, '_blank');
        }

        // تهيئة العناصر عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            // تهيئة Select2
            $('.select2').select2({
                placeholder: "اختر المنتج",
                allowClear: true,
                language: {
                    noResults: function() {
                        return "لا توجد نتائج";
                    }
                }
            });

            // عرض رصيد المورد إذا كان محدداً مسبقاً
            const selectElement = document.getElementById('clientSelect');
            if (selectElement.value) {
                showSupplierBalance(selectElement);
            }

            // تهيئة TinyMCE إذا كان متوفراً
            if (typeof tinymce !== 'undefined') {
                tinymce.init({
                    selector: '#tinyMCE',
                    height: 200,
                    menubar: false,
                    plugins: [
                        'advlist autolink lists link image charmap print preview anchor',
                        'searchreplace visualblocks code fullscreen',
                        'insertdatetime media table paste code help wordcount'
                    ],
                    toolbar: 'undo redo | formatselect | bold italic backcolor | \
                        alignleft aligncenter alignright alignjustify | \
                        bullist numlist outdent indent | removeformat | help',
                    language: 'ar',
                    directionality: 'rtl'
                });
            }

            // إضافة تلميحات للأزرار
            $('[title]').tooltip();

            // إضافة الأزرار الإضافية
            let toolbarDiv = document.querySelector('.d-flex .btn-group');
            if (toolbarDiv) {
                let additionalButtons = `
                    <button type="button" class="btn btn-outline-info btn-sm" onclick="exportToPDF()" title="تصدير PDF">
                        <i class="fa fa-file-pdf"></i> PDF
                    </button>
                    <button type="button" class="btn btn-outline-primary btn-sm" onclick="sendByEmail()" title="إرسال بالبريد">
                        <i class="fa fa-envelope"></i> إرسال
                    </button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" onclick="printInvoice()" title="طباعة">
                        <i class="fa fa-print"></i> طباعة
                    </button>
                `;

                toolbarDiv.insertAdjacentHTML('beforeend', additionalButtons);
            }

            // تحديث أرقام الصفوف بعد التحميل
            updateRowNumbers();
        });

        // وظيفة تحديث أرقام الصفوف
        function updateRowNumbers() {
            document.querySelectorAll('.item-row').forEach(function(row, index) {
                row.querySelectorAll('input, select').forEach(function(input) {
                    if (input.name) {
                        input.name = input.name.replace(/\[\d+\]/, `[${index}]`);
                    }
                });
            });
        }

        // رسالة تأكيد عند مغادرة الصفحة مع وجود تغييرات غير محفوظة
        let hasUnsavedChanges = false;
        let originalFormData = new FormData(document.getElementById('invoice-form'));

        document.addEventListener('input', function() {
            hasUnsavedChanges = true;
        });

        document.addEventListener('change', function() {
            hasUnsavedChanges = true;
        });

        document.getElementById('invoice-form').addEventListener('submit', function() {
            hasUnsavedChanges = false;
        });

        window.addEventListener('beforeunload', function(e) {
            if (hasUnsavedChanges) {
                e.preventDefault();
                e.returnValue = 'لديك تغييرات غير محفوظة. هل تريد المغادرة؟';
                return e.returnValue;
            }
        });

        // إضافة وظائف لوحة المفاتيح المختصرة
        document.addEventListener('keydown', function(e) {
            // Ctrl + S للحفظ
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                document.getElementById('invoice-form').submit();
            }

            // Ctrl + D للحفظ كمسودة
            if (e.ctrlKey && e.key === 'd') {
                e.preventDefault();
                saveAsDraft();
            }

            // Ctrl + P للطباعة
            if (e.ctrlKey && e.key === 'p') {
                e.preventDefault();
                printInvoice();
            }

            // F2 لإضافة صف جديد
            if (e.key === 'F2') {
                e.preventDefault();
                addNewRow();
            }

            // F3 للمعاينة السريعة
            if (e.key === 'F3') {
                e.preventDefault();
                showQuickPreview();
            }

            // Delete لحذف الفاتورة (مع Ctrl+Shift)
            if (e.ctrlKey && e.shiftKey && e.key === 'Delete') {
                e.preventDefault();
                deleteInvoice();
            }
        });

        // تسجيل الأخطاء للمطورين
        window.addEventListener('error', function(e) {
            console.error('JavaScript Error:', e.error);
        });

        console.log('Invoice Edit System Loaded Successfully ✅');
        console.log('Invoice ID:', invoiceId);
        console.log('Edit Mode:', isEditMode);
    </script>

    <!-- CSS إضافي لسجل التعديلات -->
    <style>
        .timeline {
            position: relative;
            padding-left: 30px;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #e9ecef;
        }

        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }

        .timeline-marker {
            position: absolute;
            left: -23px;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #007bff;
            border: 2px solid #fff;
            box-shadow: 0 0 0 2px #e9ecef;
        }

        .timeline-content {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-left: 3px solid #007bff;
        }

        .timeline-title {
            margin: 0 0 5px 0;
            font-weight: 600;
            color: #495057;
        }

        .timeline-text {
            margin: 0 0 5px 0;
            color: #6c757d;
        }

        .badge {
            padding: 0.25em 0.6em;
            font-size: 0.75em;
            font-weight: 700;
            line-height: 1;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25rem;
        }

        .badge-success {
            color: #fff;
            background-color: #28a745;
        }

        .badge-warning {
            color: #212529;
            background-color: #ffc107;
        }

        .badge-secondary {
            color: #fff;
            background-color: #6c757d;
        }

        .notification-toast {
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            border-radius: 8px;
        }

        /* تحسين شكل الكروت */
        .card {
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 8px;
        }

        .card-header {
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
            border-radius: 8px 8px 0 0 !important;
        }

        /* تحسين الجداول */
        .table th {
            background: #f8f9fa;
            border-top: none;
            font-weight: 600;
            color: #495057;
        }

        .table td {
            vertical-align: middle;
        }

        /* تحسين الأزرار */
        .btn {
            border-radius: 6px;
            font-weight: 500;
        }

        .btn-group .btn {
            border-radius: 0;
        }

        .btn-group .btn:first-child {
            border-radius: 6px 0 0 6px;
        }

        .btn-group .btn:last-child {
            border-radius: 0 6px 6px 0;
        }

        /* تحسين النماذج */
        .form-control {
            border-radius: 6px;
            border: 1px solid #ced4da;
        }

        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }

        /* تحسين التبويبات */
        .nav-tabs .nav-link {
            border: none;
            border-radius: 8px 8px 0 0;
            margin-right: 2px;
        }

        .nav-tabs .nav-link.active {
            background: #007bff;
            color: white;
        }

        /* تحسين الصفحة للجوال */
        @media (max-width: 768px) {
            .btn-group {
                flex-direction: column;
            }

            .btn-group .btn {
                border-radius: 6px;
                margin-bottom: 2px;
            }

            .table-responsive {
                border-radius: 8px;
            }
        }
    </style>
@endsection
