<?php

namespace Modules\Reports\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ChecksController extends Controller
{
    public function index()
    {
        return view('reports::checks.index');
    }
    public function delivered()
    {
        return view('reports::checks.delivered-checks');
    }
    public function received()
    {
        return view('reports::checks.received-checks');
    }
}
