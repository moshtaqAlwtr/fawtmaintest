@extends('master')

@section('title')
    إدارة العملاء
@stop

@section('css')
    <link rel="stylesheet" href="{{ asset('assets/css/indexclient.css') }}">
@stop

@section('content')
    @include('layouts.alerts.success')
    @include('layouts.alerts.error')

    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-left mb-0">إدارة العملاء</h2>
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="">الرئيسية</a></li>
                            <li class="breadcrumb-item active">عرض</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content-body">

        <div class="position-relative">
            <!-- زر فتح/إغلاق الخريطة مع تلميح عائم -->
            <button id="toggleMapButton" style="margin-top: 30px;" class="map-toggle-button" data-tooltip="إظهار الخريطة">
                <i class="fas fa-map-marked-alt"></i>
            </button>

            <div id="mapContainer" style="display: none;">
                <!-- باقي العناصر كما هي -->
                <div id="map"></div>
                <div class="pac-card">
                    <div class="search-container">
                        <input type="text" id="clientSearch" class="search-box" placeholder="ابحث عن عميل...">
                        <i class="fas fa-search search-icon"></i>
                    </div>
                </div>
                <div class="map-controls">
                    <div class="map-control-group">
                        <button class="map-control-button" onclick="map.setZoom(map.getZoom() + 1)" title="تكبير">
                            <i class="fas fa-plus"></i>
                        </button>
                        <button class="map-control-button" onclick="map.setZoom(map.getZoom() - 1)" title="تصغير">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                    <div class="map-control-group">
                        <button class="map-control-button" onclick="getCurrentLocation()" title="موقعي الحالي">
                            <i class="fas fa-location-arrow"></i>
                        </button>
                        <button class="map-control-button" onclick="resetMapView()" title="إعادة ضبط الخريطة">
                            <i class="fas fa-redo-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>



        <script>
            const toggleButton = document.getElementById('toggleMapButton');
            const mapContainer = document.getElementById('mapContainer');

            toggleButton.addEventListener('click', function() {
                const isHidden = mapContainer.style.display === 'none';

                mapContainer.style.display = isHidden ? 'block' : 'none';
                this.innerHTML = isHidden ? '<i class="fas fa-map"></i>' : '<i class="fas fa-map-marked-alt"></i>';
                this.setAttribute('data-tooltip', isHidden ? 'إخفاء الخريطة' : 'إظهار الخريطة');

                if (isHidden) {
                    // تأخير إعادة تحميل الخريطة لضمان أن العنصر ظاهر
                    setTimeout(() => {
                        if (typeof map !== 'undefined') {
                            google.maps.event.trigger(map, 'resize');

                            // إعادة مركزة الخريطة إذا كانت هناك علامات
                            if (allMarkers.length > 0) {
                                const bounds = new google.maps.LatLngBounds();
                                allMarkers.forEach(marker => {
                                    bounds.extend(marker.marker.getPosition());
                                });
                                map.fitBounds(bounds);
                            }
                        }
                    }, 300);
                }
            });
        </script>
        <!-- بطاقة الإجراءات -->
        <div class="card shadow-sm border-0 rounded-3">
            <div class="card-body p-3">
                <div class="d-flex flex-wrap justify-content-end" style="gap: 10px;">

                    <!-- زر أضف العميل -->

                    <!-- زر تحميل ملف -->
                    <label class="bg-white border d-flex align-items-center justify-content-center"
                        style="width: 44px; height: 44px; cursor: pointer; border-radius: 6px;" title="تحميل ملف">
                        <i class="fas fa-cloud-upload-alt text-primary"></i>
                        <input type="file" name="file" class="d-none">
                    </label>

                    <!-- زر استيراد -->
                    <button type="submit" class="bg-white border d-flex align-items-center justify-content-center"
                        style="width: 44px; height: 44px; border-radius: 6px;" title="استيراد ك Excel">
                        <i class="fas fa-database text-primary"></i>
                    </button>

                    <!-- زر حد ائتماني -->
                    <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#creditLimitModal"
                        class="bg-white border d-flex align-items-center justify-content-center"
                        style="width: 44px; height: 44px; border-radius: 6px;" title="حد ائتماني">
                        <i class="fas fa-credit-card text-primary"></i>
                    </a>

                    <!-- زر تصدير ك Excel (الجديد) -->
                    <button id="exportExcelBtn" class="bg-white border d-flex align-items-center justify-content-center"
                        style="width: 44px; height: 44px; border-radius: 6px;" title="تصدير ك Excel">
                        <i class="fas fa-file-excel text-primary"></i>
                    </button>

                    <a href="{{ route('clients.create') }}"
                        class="btn btn-success d-flex align-items-center justify-content-center"
                        style="height: 44px; padding: 0 16px; font-weight: bold; border-radius: 6px;">
                        <i class="fas fa-plus ms-2"></i>
                        أضف العميل
                    </a>
                </div>
            </div>
        </div>



        <!-- بطاقة البحث -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center p-2">
                <div class="d-flex gap-2">
                    <span class="hide-button-text">بحث وتصفية</span>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <button class="btn btn-outline-secondary btn-sm" onclick="toggleSearchFields(this)">
                        <i class="fa fa-times"></i>
                        <span class="hide-button-text">إخفاء</span>
                    </button>
                    <button class="btn btn-outline-secondary btn-sm" data-bs-toggle="collapse"
                        data-bs-target="#advancedSearchForm" onclick="toggleSearchText(this)">
                        <i class="fa fa-filter"></i>
                        <span class="button-text">متقدم</span>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form class="form" id="searchForm" method="GET" action="{{ route('clients.index') }}">
                    <div class="card p-3 mb-4">
                        <div class="row g-3 align-items-end">
                            <!-- اسم العميل -->
                            <div class="col-md-4 col-12">
                                <label for="client" class="form-label">العميل</label>
                                <select name="client" id="client" class="form-control select2">
                                    <option value="">اختر العميل</option>
                                    @foreach ($allClients as $client)
                                        <option value="{{ $client->id }}"
                                            {{ request('client') == $client->id ? 'selected' : '' }}>
                                            {{ $client->trade_name }} - {{ $client->code }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- الاسم -->

                            <!-- الحالة -->
                            <div class="col-md-4 col-12">
                                <label for="status" class="form-label">الحالة</label>
                                <select name="status" id="status" class="form-control">
                                    <option value="">اختر الحالة</option>
                                    @foreach ($statuses as $status)
                                        <option value="{{ $status->id }}"
                                            {{ request('status') == $status->id ? 'selected' : '' }}>
                                            {{ $status->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- المجموعة -->
                            <div class="col-md-4 col-12">
                                <label for="region" class="form-label">المجموعة</label>
                                <select name="region" id="region" class="form-control select2">
                                    <option value="">اختر المجموعة</option>
                                    @foreach ($Region_groups as $Region_group)
                                        <option value="{{ $Region_group->id }}"
                                            {{ request('region') == $Region_group->id ? 'selected' : '' }}>
                                            {{ $Region_group->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- الحي -->
                            <div class="col-md-4 col-12">
                                <label for="neighborhood" class="form-label">الحي</label>
                                <input type="text" name="neighborhood" id="neighborhood" class="form-control"
                                    placeholder="الحي" value="{{ request('neighborhood') }}">
                            </div>

                            <!-- تاريخ من -->
                            <div class="col-md-4 col-12">
                                <label for="date_from" class="form-label">تاريخ من</label>
                                <input type="date" name="date_from" id="date_from" class="form-control"
                                    value="{{ request('date_from') }}">
                            </div>

                            <!-- تاريخ الى -->
                            <div class="col-md-4 col-12">
                                <label for="date_to" class="form-label">تاريخ الى</label>
                                <input type="date" name="date_to" id="date_to" class="form-control"
                                    value="{{ request('date_to') }}">
                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="advancedSearchForm">
                        <div class="row g-3 mt-2">
                            <!-- التصنيف -->
                            <div class="col-md-4 col-12">
                                <label for="classifications" class="form-label">التصنيف</label>
                                <select name="categories" id="classifications" class="form-control">
                                    <option value="">اختر التصنيف</option>
                                    @foreach ($categories as $category)
                                        <option value="{{ $category->id }}"
                                            {{ request('categories') == $category->id ? 'selected' : '' }}>
                                            {{ $category->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- أضيفت بواسطة -->
                            <div class="col-md-4 col-12">
                                <label for="user" class="form-label">أضيفت بواسطة</label>
                                <select name="user" id="user" class="form-control select2">
                                    <option value="">أضيفت بواسطة</option>
                                    @foreach ($users as $user)
                                        <option value="{{ $user->id }}"
                                            {{ request('user') == $user->id ? 'selected' : '' }}>
                                            {{ $user->name }} - {{ $user->id }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <!-- النوع -->


                            <!-- الموظفين المعيين -->
                            <div class="col-md-4 col-12">
                                <label for="employee" class="form-label">الموظفين المعيين</label>
                                <select id="feedback2" class="form-control select2" name="employee[]"
                                    multiple="multiple">
                                    <option value="">اختر الموظفين المعيين</option>
                                    @foreach ($employees as $employee)
                                        <option value="{{ $employee->id }}"
                                            {{ request('employee') == $employee->id ? 'selected' : '' }}>
                                            {{ $employee->full_name }} - {{ $employee->id }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions mt-2">
                        <button type="submit" class="btn btn-primary">بحث</button>
                        <a href="{{ route('clients.index') }}" type="reset" class="btn btn-outline-warning">إلغاء</a>
                    </div>
                </form>
            </div>
        </div>



        <!-- جدول العملاء -->
        <!-- جدول العملاء -->
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
                    <!-- شريط الترقيم -->
                    @if ($clients->hasPages())
                        <nav aria-label="Page navigation">
                            <ul class="pagination pagination-sm mb-0 pagination-links">
                                <!-- أول صفحة -->
                                @if ($clients->onFirstPage())
                                    <li class="page-item disabled">
                                        <span class="page-link border-0 rounded-pill" aria-label="First">
                                            <i class="fas fa-angle-double-right"></i>
                                        </span>
                                    </li>
                                @else
                                    <li class="page-item">
                                        <a class="page-link border-0 rounded-pill pagination-link"
                                            href="{{ $clients->appends(request()->query())->url(1) }}" aria-label="First"
                                            data-page="1">
                                            <i class="fas fa-angle-double-right"></i>
                                        </a>
                                    </li>
                                @endif

                                <!-- الصفحة السابقة -->
                                @if ($clients->onFirstPage())
                                    <li class="page-item disabled">
                                        <span class="page-link border-0 rounded-pill" aria-label="Previous">
                                            <i class="fas fa-angle-right"></i>
                                        </span>
                                    </li>
                                @else
                                    <li class="page-item">
                                        <a class="page-link border-0 rounded-pill pagination-link"
                                            href="{{ $clients->appends(request()->query())->previousPageUrl() }}"
                                            aria-label="Previous" data-page="{{ $clients->currentPage() - 1 }}">
                                            <i class="fas fa-angle-right"></i>
                                        </a>
                                    </li>
                                @endif

                                <!-- رقم الصفحة -->
                                <li class="page-item">
                                    <span class="page-link border-0 bg-light rounded-pill px-3">
                                        صفحة {{ $clients->currentPage() }} من {{ $clients->lastPage() }}
                                    </span>
                                </li>

                                <!-- الصفحة التالية -->
                                @if ($clients->hasMorePages())
                                    <li class="page-item">
                                        <a class="page-link border-0 rounded-pill pagination-link"
                                            href="{{ $clients->appends(request()->query())->nextPageUrl() }}"
                                            aria-label="Next" data-page="{{ $clients->currentPage() + 1 }}">
                                            <i class="fas fa-angle-left"></i>
                                        </a>
                                    </li>
                                @else
                                    <li class="page-item disabled">
                                        <span class="page-link border-0 rounded-pill" aria-label="Next">
                                            <i class="fas fa-angle-left"></i>
                                        </span>
                                    </li>
                                @endif

                                <!-- آخر صفحة -->
                                @if ($clients->hasMorePages())
                                    <li class="page-item">
                                        <a class="page-link border-0 rounded-pill pagination-link"
                                            href="{{ $clients->appends(request()->query())->url($clients->lastPage()) }}"
                                            aria-label="Last" data-page="{{ $clients->lastPage() }}">
                                            <i class="fas fa-angle-double-left"></i>
                                        </a>
                                    </li>
                                @else
                                    <li class="page-item disabled">
                                        <span class="page-link border-0 rounded-pill" aria-label="Last">
                                            <i class="fas fa-angle-double-left"></i>
                                        </span>
                                    </li>
                                @endif
                            </ul>
                        </nav>
                    @endif

                    <!-- اختيار عدد العملاء -->
                    <div class="d-flex align-items-center mb-2 mb-md-0">
                        <label for="cardsPerPage" class="me-2">أظهر</label>
                        <select id="cardsPerPage" class="form-select form-select-sm w-auto" style="min-width: 80px;">
                            <option value="10" {{ request('perPage') == 10 ? 'selected' : '' }}>10</option>
                            <option value="25" {{ request('perPage') == 25 ? 'selected' : '' }}>25</option>
                            <option value="50" {{ request('perPage') == 50 ? 'selected' : '' }}>50</option>
                            <option value="100" {{ request('perPage') == 100 ? 'selected' : '' }}>100</option>
                        </select>
                        <span class="ms-2">مدخلات</span>
                    </div>
                </div>

                <div id="clients-container">
                    @include('client::partials.client_cards', ['clients' => $clients])
                </div>
            </div>
        </div>

        <!-- Modal إضافة حد ائتماني -->
        <div class="modal fade" id="creditLimitModal" tabindex="-1" aria-labelledby="creditLimitModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="creditLimitModalLabel">تعديل الحد الائتماني</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="{{ route('clients.update_credit_limit') }}" method="POST">
                        @csrf
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="credit_limit" class="form-label">
                                    الحد الائتماني الحالي: <span
                                        id="current_credit_limit">{{ $creditLimit->value ?? 'غير محدد' }}</span>
                                </label>
                                <input type="number" class="form-control" id="credit_limit" name="value"
                                    value="{{ $creditLimit->value ?? '' }}" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                            <button type="submit" class="btn btn-primary">حفظ</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    @endsection

    @section('scripts')
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
        <script src="https://unpkg.com/@googlemaps/markerclusterer/dist/index.min.js"></script>

        <script
            src="https://maps.googleapis.com/maps/api/js?key={{ env('GOOGLE_MAPS_API_KEY') }}&libraries=places&callback=window.initMap"
            async defer></script>

        <script>
            // أضف هذه المكتبة في رأس HTML

            let map;
            let infoWindow;
            let currentUserMarker;
            let allMarkers = [];
            let markerCluster;

            function initMap() {
                // إعدادات الخريطة الأساسية
                const mapOptions = {
                    zoom: 10,
                    center: {
                        lat: 24.7136,
                        lng: 46.6753
                    },
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    styles: [{
                        featureType: "poi",
                        elementType: "labels",
                        stylers: [{
                            visibility: "off"
                        }]
                    }]
                };

                map = new google.maps.Map(document.getElementById('map'), mapOptions);
                infoWindow = new google.maps.InfoWindow({
                    maxWidth: 300
                });

                // تحديد موقع الموظف إذا كان متاحًا
                @if (auth()->user()->role === 'employee' && auth()->user()->location)
                    const userLocation = {
                        lat: {{ auth()->user()->location->latitude }},
                        lng: {{ auth()->user()->location->longitude }}
                    };

                    map.setCenter(userLocation);

                    currentUserMarker = new google.maps.Marker({
                        position: userLocation,
                        map: map,
                        icon: {
                            url: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                            scaledSize: new google.maps.Size(40, 40)
                        },
                        title: "موقعك الحالي",
                        animation: google.maps.Animation.DROP
                    });

                    new google.maps.Circle({
                        strokeColor: "#4285F4",
                        strokeOpacity: 0.8,
                        strokeWeight: 2,
                        fillColor: "#4285F4",
                        fillOpacity: 0.1,
                        map: map,
                        center: userLocation,
                        radius: 1000
                    });
                @endif

                // تحميل العلامات
                loadMarkers([

                    @foreach ($allClients as $client)
                        @if ($client->locations && $client->locations->latitude && $client->locations->longitude)
                            {
                                id: {{ $client->id }},
                                lat: {{ $client->locations->latitude }},
                                lng: {{ $client->locations->longitude }},
                                trade_name: '{{ addslashes($client->trade_name) }}',
                                code: '{{ $client->code }}',
                                phone: '{{ $client->phone }}',
                                address: '{{ addslashes(optional($client->locations)->address) }}',
                                status: '{{ optional($client->status_client)->name ?? 'غير محدد' }}',
                                statusColor: '{{ optional($client->status_client)->color ?? '#4CAF50' }}',
                                branch: '{{ optional($client->branch)->name }}',
                                distance: {{ isset($client->distance) ? round($client->distance, 2) : 'null' }},
                                balance: {{ $client->balance ?? 0 }}
                            },
                        @endif
                    @endforeach
                ]);

                // تفعيل البحث في الخريطة
                const searchInput = document.getElementById('clientSearch');
                searchInput.addEventListener('input', function() {
                    const searchValue = this.value.toLowerCase().trim();
                    filterMarkers(searchValue);
                });
            }

            // دالة لتحميل العلامات مع التصميم الجديد
            // دالة لتحميل العلامات مع تصميم الفقاعة
                  function loadMarkers(clientsData) {
            allMarkers = [];

            clientsData.forEach(client => {
                // تحديث حالة العميل بناءً على الملاحظات (للموظفين فقط)
                @if (auth()->user()->role === 'employee')
                    if (client.lastNote) {
                        const statusToShow = {!! json_encode($statuses) !!}.find(s => s.id == client.lastNote.employee_view_status);
                        if (statusToShow) {
                            client.statusColor = statusToShow.color;
                            client.status = statusToShow.name;
                        }
                    }
                @endif

                // إنشاء علامة على شكل فقاعة محادثة
                const marker = new google.maps.Marker({
                    position: {
                        lat: client.lat,
                        lng: client.lng
                    },
                    map: map,
                    title: `${client.trade_name} (${client.code})`,
                    icon: {
                        url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                            <svg xmlns="http://www.w3.org/2000/svg" width="44" height="36" viewBox="0 0 44 36">
                                <path d="M12 0h20c6.6 0 12 5.4 12 12v10c0 6.6-5.4 12-12 12H24l-8 8V34H12C5.4 34 0 28.6 0 22V12C0 5.4 5.4 0 12 0z"
                                    fill="${client.statusColor}"
                                    stroke="#ffffff"
                                    stroke-width="1"/>
                                <path d="M24 34l-4 4v-4h-8c-6.6 0-12-5.4-12-12V12C0 5.4 5.4 0 12 0h20c6.6 0 12 5.4 12 12v10c0 6.6-5.4 12-12 12H24z"
                                    fill="${client.statusColor}"/>
                                <text x="22" y="22" font-family="Arial" font-size="14" font-weight="bold"
                                    fill="white" text-anchor="middle" dominant-baseline="middle">
                                    ${client.code}
                                </text>
                            </svg>
                        `),
                        scaledSize: new google.maps.Size(44, 36),
                        anchor: new google.maps.Point(22, 36)
                    }
                });

                marker.addListener('click', () => {
                    showClientInfo({
                        marker: marker,
                        data: {
                            id: client.id,
                            name: client.trade_name,
                            code: client.code,
                            phone: client.phone,
                            address: client.address,
                            status: client.status,
                            statusColor: client.statusColor,
                            branch: client.branch,
                            distance: client.distance,
                            balance: client.balance
                        }
                    });
                });

                allMarkers.push({
                    marker: marker,
                    clientName: client.trade_name.toLowerCase(),
                    clientCode: client.code.toLowerCase(),
                    distance: client.distance || Infinity
                });
            });

            // تجميع العلامات
            if (typeof markerClusterer !== 'undefined' && allMarkers.length > 0) {
                markerCluster = new markerClusterer.MarkerClusterer({
                    map,
                    markers: allMarkers.map(m => m.marker),
                    renderer: {
                        render: ({ count, position }) => {
                            return new google.maps.Marker({
                                position,
                                label: { text: String(count), color: "white" },
                                icon: {
                                    path: google.maps.SymbolPath.CIRCLE,
                                    scale: 20,
                                    fillColor: "#4285F4",
                                    fillOpacity: 0.8,
                                    strokeWeight: 2,
                                    strokeColor: "#4285F4"
                                }
                            });
                        }
                    }
                });
            }

            fitMapToMarkers();
        }

            // باقي الدوال تبقى كما هي (showClientInfo, filterMarkers, fitMapToMarkers, etc.)
            function showClientInfo(markerData) {
                if (infoWindow) infoWindow.close();

                const contentString = `
            <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; width: 300px;">
                <div style="background: ${markerData.data.statusColor}; color: white; padding: 16px; text-align: center; border-radius: 8px 8px 0 0;">
                    <h6 style="margin: 0; font-size: 18px; font-weight: 700;">
                        ${markerData.data.name}
                    </h6>
                    <div style="margin-top: 5px; font-size: 14px;">${markerData.data.code}</div>
                </div>

                <div style="padding: 16px; background: white; border-radius: 0 0 8px 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    <div style="display: grid; gap: 8px;">
                        <div style="display: flex; align-items: center;">
                            <i class="fas fa-phone" style="color: #6c757d; width: 20px;"></i>
                            <span style="margin-right: 8px; color: #6c757d;">الهاتف:</span>
                            <a href="tel:${markerData.data.phone}" style="color: #4361ee; text-decoration: none;">
                                ${markerData.data.phone}
                            </a>
                        </div>

                    </div>

                    <div style="display: flex; gap: 8px; margin-top: 16px;">
                        <button onclick="window.location.href='{{ route('clients.show', '') }}/${markerData.data.id}'"
                            style="flex: 1; padding: 8px; background: #4361ee; color: white; border: none; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-info-circle"></i> التفاصيل
                        </button>
                        <button onclick="openMap(${markerData.marker.getPosition().lat()}, ${markerData.marker.getPosition().lng()})"
                            style="flex: 1; padding: 8px; background: white; color: #4361ee; border: 1px solid #4361ee; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-map-marked-alt"></i> الخريطة
                        </button>
                    </div>
                </div>
            </div>
        `;

                infoWindow = new google.maps.InfoWindow({
                    content: contentString
                });
                infoWindow.open(map, markerData.marker);
            }
            // تصفية العلامات حسب البحث
            function filterMarkers(searchValue) {
                let anyVisible = false;

                allMarkers.forEach(item => {
                    const isVisible = item.clientName.includes(searchValue) ||
                        item.clientCode.includes(searchValue);

                    item.marker.setVisible(isVisible);

                    if (isVisible) {
                        anyVisible = true;

                        // إذا كان البحث مطابق تماماً لاسم أو كود العميل
                        if (item.clientName === searchValue || item.clientCode === searchValue) {
                            showClientInfo({
                                marker: item.marker,
                                data: {
                                    id: item.id,
                                    name: item.clientName,
                                    code: item.clientCode,
                                    phone: item.phone,
                                    address: item.address,
                                    status: item.status,
                                    statusColor: item.statusColor,
                                    branch: item.branch,
                                    distance: item.distance,
                                    balance: item.balance
                                }
                            });
                            map.panTo(item.marker.getPosition());
                            map.setZoom(15);
                        }
                    }
                });

                if (!anyVisible && searchValue) {
                    alert("لا توجد نتائج مطابقة للبحث");
                }
            }

            // فتح خرائط جوجل في نافذة جديدة
            function openMap(lat, lng, title = '') {
                if (lat === 0 || lng === 0) {
                    alert('لا يوجد إحداثيات متاحة لهذا العميل');
                    return;
                }
                window.open(`https://www.google.com/maps?q=${lat},${lng}&z=17`, '_blank');
            }

            // الحصول على الموقع الحالي
            function getCurrentLocation() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        (position) => {
                            const pos = {
                                lat: position.coords.latitude,
                                lng: position.coords.longitude
                            };

                            if (currentUserMarker) {
                                currentUserMarker.setPosition(pos);
                            } else {
                                currentUserMarker = new google.maps.Marker({
                                    position: pos,
                                    map: map,
                                    icon: {
                                        url: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                                        scaledSize: new google.maps.Size(40, 40)
                                    },
                                    title: "موقعك الحالي",
                                    animation: google.maps.Animation.DROP
                                });
                            }

                            map.setCenter(pos);
                            map.setZoom(14);
                        },
                        () => {
                            alert("فشل في الحصول على الموقع. يرجى التأكد من تفعيل صلاحيات الموقع.");
                        }
                    );
                } else {
                    alert("المتصفح لا يدعم خدمة الموقع الجغرافي.");
                }
            }

            // إعادة تعيين عرض الخريطة
            function resetMapView() {
                if (currentUserMarker) {
                    map.setCenter(currentUserMarker.getPosition());
                    map.setZoom(14);
                } else {
                    map.setCenter({
                        lat: 24.7136,
                        lng: 46.6753
                    });
                    map.setZoom(10);
                }
                if (infoWindow) infoWindow.close();
            }

            // التحكم في فتح/إغلاق الخريطة
            // التحكم في فتح/إغلاق الخريطة
            document.addEventListener('DOMContentLoaded', function() {
                const toggleButton = document.getElementById('toggleMapButton');
                const mapContainer = document.getElementById('mapContainer');
                const clientSearch = document.getElementById('clientSearch');

                let isMapOpen = localStorage.getItem('mapOpen') === 'true';

                function initializeMapState() {
                    if (isMapOpen) {
                        mapContainer.style.display = 'block';
                        toggleButton.innerHTML = '<i class="fas fa-map"></i>';
                        toggleButton.setAttribute('data-tooltip', 'إخفاء الخريطة');

                        setTimeout(() => {
                            if (typeof map !== 'undefined') {
                                google.maps.event.trigger(map, 'resize');
                                fitMapToMarkers(); // إذا عندك دالة تركّز على الماركرات
                            }
                        }, 300);
                    } else {
                        mapContainer.style.display = 'none';
                        toggleButton.innerHTML = '<i class="fas fa-map-marked-alt"></i>';
                        toggleButton.setAttribute('data-tooltip', 'إظهار الخريطة');
                    }
                }

                // تشغيل تهيئة الخريطة
                initializeMapState();

                // حل المشكلة: إضافة حدث عند الضغط على الزر
                toggleButton.addEventListener('click', function() {
                    isMapOpen = !isMapOpen;
                    localStorage.setItem('mapOpen', isMapOpen);
                    initializeMapState();
                });
            });

            // دالة مساعدة لضبط عرض الخريطة ليشمل العلامات المرئية فقط
            function fitVisibleMarkers() {
                if (allMarkers.length === 0) return;

                const bounds = new google.maps.LatLngBounds();
                let hasVisibleMarkers = false;

                allMarkers.forEach(item => {
                    if (item.marker.getVisible()) {
                        bounds.extend(item.marker.getPosition());
                        hasVisibleMarkers = true;
                    }
                });

                if (hasVisibleMarkers) {
                    const maxZoom = 14;
                    const listener = google.maps.event.addListener(map, 'bounds_changed', function() {
                        if (map.getZoom() > maxZoom) map.setZoom(maxZoom);
                        google.maps.event.removeListener(listener);
                    });

                    map.fitBounds(bounds);
                } else {
                    // إذا لم تكن هناك علامات مرئية، عرض الخريطة بالكامل
                    resetMapView();
                }
            }
        </script>
        <script>
            $(document).ready(function() {
                // متغير لتخزين حالة الخريطة
                let isMapOpen = localStorage.getItem('mapOpen') === 'true';
                let loadingTimer;

                // تهيئة حالة الخريطة
                function initializeMapState() {
                    const mapContainer = $('#mapContainer');
                    const toggleButton = $('#toggleMapButton');

                    if (isMapOpen) {
                        mapContainer.show();
                        toggleButton.html('<i class="fas fa-map"></i>');
                        toggleButton.attr('data-tooltip', 'إخفاء الخريطة');

                        setTimeout(() => {
                            if (typeof map !== 'undefined') {
                                google.maps.event.trigger(map, 'resize');
                                fitMapToMarkers();
                            }
                        }, 300);
                    } else {
                        mapContainer.hide();
                        toggleButton.html('<i class="fas fa-map-marked-alt"></i>');
                        toggleButton.attr('data-tooltip', 'إظهار الخريطة');
                    }
                }

                // تهيئة أولية
                initializeMapState();

                // حدث تغيير عدد العناصر المعروضة
                $('#cardsPerPage').change(function() {
                    const perPage = $(this).val();
                    updateQueryStringParameter('perPage', perPage);
                    loadClients();
                });

                // أحداث التنقل بين الصفحات
                $(document).on('click', '.pagination-link', function(e) {
                    e.preventDefault();
                    const url = $(this).attr('href');
                    const page = $(this).data('page');
                    updateQueryStringParameter('page', page);
                    loadClients();
                });

                // دالة تحميل العملاء عبر AJAX
                function loadClients() {
                    const queryParams = new URLSearchParams(window.location.search);
                    const url = '{{ route('clients.index') }}?' + queryParams.toString();

                    // إظهار رسالة التحميل بعد تأخير بسيط
                    loadingTimer = setTimeout(() => {
                        $('#clients-container').html(`
                <div class="text-center py-5" style="min-height: 300px;">
                    <div class="loading-animation mb-4">
                        <div class="dot-pulse"></div>
                    </div>
                    <h5 class="text-primary mb-2">جارٍ تحديث البيانات...</h5>
                    <p class="text-muted small">سيتم عرض النتائج خلال لحظات</p>
                </div>
                <style>
                    .dot-pulse {
                        position: relative;
                        left: -9999px;
                        width: 10px;
                        height: 10px;
                        border-radius: 5px;
                        background-color: #4361ee;
                        color: #4361ee;
                        box-shadow: 9999px 0 0 -5px #4361ee;
                        animation: dot-pulse 1.5s infinite linear;
                        animation-delay: 0.25s;
                        margin: 0 auto;
                    }
                    .dot-pulse::before, .dot-pulse::after {
                        content: "";
                        display: inline-block;
                        position: absolute;
                        top: 0;
                        width: 10px;
                        height: 10px;
                        border-radius: 5px;
                        background-color: #4361ee;
                        color: #4361ee;
                    }
                    .dot-pulse::before {
                        box-shadow: 9984px 0 0 -5px #4361ee;
                        animation: dot-pulse-before 1.5s infinite linear;
                        animation-delay: 0s;
                    }
                    .dot-pulse::after {
                        box-shadow: 10014px 0 0 -5px #4361ee;
                        animation: dot-pulse-after 1.5s infinite linear;
                        animation-delay: 0.5s;
                    }
                    @keyframes dot-pulse-before {
                        0% { box-shadow: 9984px 0 0 -5px #4361ee; }
                        30% { box-shadow: 9984px 0 0 2px #4361ee; }
                        60%, 100% { box-shadow: 9984px 0 0 -5px #4361ee; }
                    }
                    @keyframes dot-pulse {
                        0% { box-shadow: 9999px 0 0 -5px #4361ee; }
                        30% { box-shadow: 9999px 0 0 2px #4361ee; }
                        60%, 100% { box-shadow: 9999px 0 0 -5px #4361ee; }
                    }
                    @keyframes dot-pulse-after {
                        0% { box-shadow: 10014px 0 0 -5px #4361ee; }
                        30% { box-shadow: 10014px 0 0 2px #4361ee; }
                        60%, 100% { box-shadow: 10014px 0 0 -5px #4361ee; }
                    }
                </style>
            `);
                    }, 200); // تأخير 200 مللي ثانية قبل إظهار رسالة التحميل

                    $.ajax({
                        url: url,
                        method: 'GET',
                        beforeSend: function() {
                            // تم نقل محتوى التحميل إلى timer
                        },
                        success: function(response) {
                            clearTimeout(loadingTimer);

                            // استخراج محتوى الكروت من الاستجابة
                            const parser = new DOMParser();
                            const htmlDoc = parser.parseFromString(response, 'text/html');
                            const cardsContent = $(htmlDoc).find('#clients-container').html();

                            // إضافة تأثير fade-in عند التحميل
                            $('#clients-container').html(cardsContent).hide().fadeIn(300);

                            // تحديث شريط الترقيم
                            const paginationContent = $(htmlDoc).find('.pagination-links').html();
                            $('.pagination-links').html(paginationContent);

                            // تحديث عنوان URL في المتصفح بدون إعادة تحميل
                            window.history.pushState({}, '', url);

                            // إعادة تهيئة حالة الخريطة
                            initializeMapState();
                        },
                        error: function() {
                            clearTimeout(loadingTimer);
                            $('#clients-container').html(`
                    <div class="alert alert-danger text-center py-4" role="alert">
                        <i class="fas fa-exclamation-triangle fa-2x mb-3"></i>
                        <h5 class="mb-0">حدث خطأ أثناء تحميل البيانات</h5>
                        <button class="btn btn-sm btn-outline-primary mt-2" onclick="loadClients()">
                            <i class="fas fa-sync-alt me-1"></i> إعادة المحاولة
                        </button>
                    </div>
                `).hide().fadeIn(300);
                        },
                        complete: function() {
                            clearTimeout(loadingTimer);
                        }
                    });
                }

                // دالة مساعدة لتحديث معاملات البحث
                function updateQueryStringParameter(key, value) {
                    const url = new URL(window.location);
                    url.searchParams.set(key, value);
                    window.history.replaceState({}, '', url);
                }

                // دعم زر الرجوع في المتصفح
                window.onpopstate = function() {
                    loadClients();
                };

                // حدث تبديل حالة الخريطة
                $('#toggleMapButton').click(function() {
                    isMapOpen = !isMapOpen;
                    localStorage.setItem('mapOpen', isMapOpen);
                    initializeMapState();
                });
            });
        </script>
    @stop
