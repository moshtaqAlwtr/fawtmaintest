<?php

return [
    'name' => 'Client',
];
