<?php

return [
    'name' => 'PointsAndBlances',
];
