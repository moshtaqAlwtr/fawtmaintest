<x-pointsandblances::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('pointsandblances.name') !!}</p>
</x-pointsandblances::layouts.master>
