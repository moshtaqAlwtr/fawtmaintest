<?php

return [
    'name' => 'RentalManagement',
];
