<?php

namespace Modules\RentalManagement\Database\Seeders;

use Illuminate\Database\Seeder;

class RentalManagementDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
