<?php

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MachinesController extends Controller
{
    public function index()
    {
        return view('hr::attendance.settings.machines.index');
    }
    public function create()
    {
        return view('hr::attendance.settings.machines.create');
    }
}
