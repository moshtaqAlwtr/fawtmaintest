<x-hr::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('hr.name') !!}</p>
</x-hr::layouts.master>
