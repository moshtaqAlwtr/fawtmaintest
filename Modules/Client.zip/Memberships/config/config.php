<?php

return [
    'name' => 'Memberships',
];
