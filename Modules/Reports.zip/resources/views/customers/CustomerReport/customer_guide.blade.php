@extends('master')

@section('title')
    تقرير دليل العملاء
@stop

@section('css')
    <!-- Google Fonts - Cairo -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Select2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/css/select2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/report.css') }}">
    <link rel="stylesheet" href="{{ asset('css/report.css') }}">
@endsection

@section('content')
    <!-- Page Header -->
    <div class="page-header">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="slide-in">
                        <i class="fas fa-address-book me-3"></i>
                        تقرير دليل العملاء
                    </h1>
                    <nav class="breadcrumb-custom">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="#"><i class="fas fa-home me-2"></i>الرئيسية</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">التقارير</a>
                            </li>
                            <li class="breadcrumb-item active">دليل العملاء</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-md-4 text-end">
                    <div class="stats-icon primary">
                        <i class="fas fa-address-book"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <!-- Filters Section -->
        <div class="card-modern fade-in">
            <div class="card-header-modern">
                <h5 class="mb-0">
                    <i class="fas fa-filter me-2"></i>
                    فلاتر التقرير
                </h5>
            </div>
            <div class="card-body-modern">
                <form id="reportForm">
                    <div class="row g-4">
                        <!-- First Row -->
                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">العميل</label>
                            <select name="customer" id="customer" class="form-control select2">
                                <option value="">جميع العملاء</option>
                                @foreach ($customers as $customer)
                                    <option value="{{ $customer->id }}">{{ $customer->trade_name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">الفرع</label>
                            <select name="branch" id="branch" class="form-control select2">
                                <option value="">جميع الفروع</option>
                                @foreach ($branches as $branch)
                                    <option value="{{ $branch->id }}">{{ $branch->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">تصنيف العميل</label>
                            <select name="customer_type" id="customer_type" class="form-control select2">
                                <option value="">جميع التصنيفات</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">المجموعة (المنطقة)</label>
                            <select name="region_group" id="region_group" class="form-control select2">
                                <option value="">جميع المجموعات</option>
                                @foreach ($regionGroups as $group)
                                    <option value="{{ $group->id }}">{{ $group->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Second Row -->
                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">الحي</label>
                            <select name="neighborhood" id="neighborhood" class="form-control select2">
                                <option value="">جميع الأحياء</option>
                                @foreach ($neighborhoods as $neighborhood)
                                    <option value="{{ $neighborhood->id }}">{{ $neighborhood->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">المدينة</label>
                            <select name="city" id="city" class="form-control select2">
                                <option value="">جميع المدن</option>
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">البلد</label>
                            <input type="text" name="country" id="country" class="form-control" placeholder="أدخل اسم البلد">
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">تجميع حسب</label>
                            <select id="group-by" name="group_by" class="form-control select2">
                                <option value="العميل">العميل</option>
                                <option value="الفرع">الفرع</option>
                                <option value="المدينة">المدينة</option>
                                <option value="المجموعة">المجموعة</option>
                                <option value="الحي">الحي</option>
                            </select>
                        </div>

                        <!-- Third Row -->
                        <div class="col-lg-3 col-md-6 d-flex align-items-center">
                            <input type="checkbox" id="view-details" name="view_details" class="form-check-input me-2">
                            <label for="view-details" class="form-check-label">مشاهدة التفاصيل</label>
                        </div>

                        <!-- Action Buttons -->
                        <div class="col-lg-12 align-self-end">
                            <div class="d-flex gap-2 flex-wrap justify-content-center">
                                <button type="button" class="btn-modern btn-primary-modern" id="filterBtn">
                                    <i class="fas fa-search"></i>
                                    عرض التقرير
                                </button>
                                <button type="button" class="btn-modern btn-outline-modern" id="resetBtn">
                                    <i class="fas fa-refresh"></i>
                                    إلغاء الفلتر
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="card-modern no-print fade-in">
            <div class="card-body-modern">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <div class="d-flex gap-2 flex-wrap">
                        <button class="btn-modern btn-success-modern" id="exportExcel">
                            <i class="fas fa-file-excel"></i>
                            تصدير إكسل
                        </button>
                        <button class="btn-modern btn-warning-modern" id="printBtn">
                            <i class="fas fa-print"></i>
                            طباعة
                        </button>
                    </div>

                    <div class="btn-group" role="group">
                        <button type="button" class="btn-modern btn-primary-modern active" id="summaryViewBtn">
                            <i class="fas fa-chart-pie"></i>
                            ملخص
                        </button>
                        <button type="button" class="btn-modern btn-outline-modern" id="detailViewBtn">
                            <i class="fas fa-list"></i>
                            تفاصيل
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4 fade-in" id="totalsSection">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stats-card">
                    <div class="stats-icon primary">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stats-value" id="totalClients">0</div>
                    <div class="stats-label">إجمالي العملاء</div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stats-card warning">
                    <div class="stats-icon warning">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="stats-value" id="clientsWithLocations">0</div>
                    <div class="stats-label">عملاء بمواقع</div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stats-card info">
                    <div class="stats-icon info">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stats-value" id="totalBranches">0</div>
                    <div class="stats-label">عدد الفروع</div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-3">
                <div class="stats-card success">
                    <div class="stats-icon success">
                        <i class="fas fa-home"></i>
                    </div>
                    <div class="stats-value" id="totalNeighborhoods">0</div>
                    <div class="stats-label">عدد الأحياء</div>
                </div>
            </div>
        </div>

        <!-- Map Section -->
        <div class="card-modern fade-in" id="chartSection">
            <div class="card-header-modern">
                <h5 class="mb-0">
                    <i class="fas fa-map-marked-alt me-2"></i>
                    خريطة مواقع العملاء
                </h5>
            </div>
            <div class="card-body-modern">
                <div class="map-container">
                    <!-- Placeholder -->
                    <div id="mapPlaceholder" class="text-center p-5">
                        <div class="placeholder-content">
                            <i class="fas fa-map-marked-alt"></i>
                            <h5>خريطة مواقع العملاء</h5>
                            <p>اختر عميلاً من الجدول لعرض موقعه على الخريطة</p>
                        </div>
                    </div>

                    <!-- Actual Map (hidden by default) -->
                    <div id="clientMap" style="height: 500px; display: none;"></div>
                </div>
            </div>
        </div>

        <!-- Report Table -->
        <div class="card-modern fade-in" id="reportContainer" style="position: relative;">
            <!-- Loading Overlay -->
            <div class="loading-overlay">
                <div class="spinner"></div>
            </div>

            <div class="card-header-modern">
                <h5 class="mb-0" id="reportTitle">
                    <i class="fas fa-table me-2"></i>
                    تقرير دليل العملاء
                </h5>
            </div>
            <div class="card-body-modern p-0">
                <div class="table-responsive">
                    <table class="table table-modern mb-0">
                        <thead>
                            <tr>

                                <th><i class="fas fa-code me-2"></i>الكود</th>
                                <th><i class="fas fa-user me-2"></i>اسم العميل</th>
                                <th><i class="fas fa-building me-2"></i>الفرع</th>
                                <th><i class="fas fa-tags me-2"></i>التصنيف</th>
                                <th><i class="fas fa-home me-2"></i>الحي</th>
                                <th><i class="fas fa-layer-group me-2"></i>المجموعة</th>
                                <th><i class="fas fa-map-marker-alt me-2"></i>الموقع</th>
                                <th><i class="fas fa-phone me-2"></i>الهاتف</th>
                                <th><i class="fas fa-mobile-alt me-2"></i>الجوال</th>
                            </tr>
                        </thead>
                        <tbody id="reportTableBody">
                            <!-- سيتم تحديث البيانات هنا عبر AJAX -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.5/xlsx.full.min.js"></script>
    <!-- Select2 JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/js/select2.min.js"></script>
    <!-- Google Maps API -->
    <script src="https://maps.googleapis.com/maps/api/js?key={{ env('GOOGLE_MAPS_API_KEY') }}&callback=initMap&libraries=places&v=weekly" async defer></script>

    <script>
        let map;
        const markers = [];
        let mapInitialized = false;

        $(document).ready(function() {
            // تهيئة Select2
            $('.select2').select2({
                theme: 'bootstrap-5',
                dir: 'rtl',
                language: {
                    noResults: function() {
                        return "لا توجد نتائج";
                    },
                    searching: function() {
                        return "جاري البحث...";
                    },
                    loadingMore: function() {
                        return "جاري تحميل المزيد...";
                    }
                },
                allowClear: true,
                width: '100%',
                dropdownParent: $('body'),
                minimumResultsForSearch: 0,
                placeholder: function() {
                    return $(this).data('placeholder') || 'اختر...';
                },
                dropdownCssClass: 'select2-dropdown-custom',
                minimumInputLength: 0,
                closeOnSelect: true,
                selectOnClose: false
            });

            // تحميل البيانات الأولية
            loadReportData();

            // Add animation classes on load
            setTimeout(() => {
                $('.fade-in').addClass('animate__animated animate__fadeInUp');
            }, 100);

            // التعامل مع تصفية التقرير
            $('#filterBtn').click(function() {
                $(this).addClass('loading');
                loadReportData();
            });

            // إعادة تعيين الفلاتر
            $('#resetBtn').click(function() {
                $('#reportForm')[0].reset();
                $('.select2').val(null).trigger('change');
                loadReportData();
            });

            // التعامل مع تصدير إكسل
            $('#exportExcel').click(function() {
                exportToExcel();
            });

            // التعامل مع الطباعة
            $('#printBtn').click(function() {
                window.print();
            });

            // تحديث البيانات عند تغيير المجموعة
            $('#region_group').on('change', function() {
                const regionGroupId = $(this).val();
                loadNeighborhoods(regionGroupId);
            });

            // تحديث البيانات عند تغيير الفرع
            $('#branch').on('change', function() {
                const branchId = $(this).val();
                loadRegionGroups(branchId);
            });

            // تحديث البيانات عند تغيير أي فلتر
            $('.select2, #reportForm input').on('change', function() {
                loadReportData();
            });

            // دالة تحميل بيانات التقرير
            function loadReportData() {
                $('.loading-overlay').fadeIn();
                $('#filterBtn').prop('disabled', true);

                const formData = $('#reportForm').serialize();

                $.ajax({
                    url: '{{ route('ClientReport.customerGuideAjax') }}',
                    method: 'GET',
                    data: formData,
                    success: function(response) {
                        updateReportDisplay(response);
                        $('.loading-overlay').fadeOut();
                        $('#filterBtn').prop('disabled', false);
                        $('#reportContainer').addClass('fade-in');
                    },
                    error: function(xhr, status, error) {
                        console.error('خطأ في تحميل البيانات:', error);
                        $('.loading-overlay').fadeOut();
                        $('#filterBtn').prop('disabled', false);
                        showAlert('حدث خطأ في تحميل البيانات. يرجى المحاولة مرة أخرى.', 'danger');
                    }
                });
            }

            // دالة تحميل الأحياء حسب المجموعة
            function loadNeighborhoods(regionGroupId) {
                if (!regionGroupId) {
                    $('#neighborhood').empty().append('<option value="">جميع الأحياء</option>');
                    return;
                }

                $.ajax({
                    url: '{{ route('ClientReport.getNeighborhoods') }}',
                    method: 'GET',
                    data: { region_group_id: regionGroupId },
                    success: function(neighborhoods) {
                        $('#neighborhood').empty().append('<option value="">جميع الأحياء</option>');
                        neighborhoods.forEach(function(neighborhood) {
                            $('#neighborhood').append(`<option value="${neighborhood.id}">${neighborhood.name}</option>`);
                        });
                    },
                    error: function() {
                        showAlert('خطأ في تحميل الأحياء', 'danger');
                    }
                });
            }

            // دالة تحميل المجموعات حسب الفرع
            function loadRegionGroups(branchId) {
                if (!branchId) {
                    $('#region_group').empty().append('<option value="">جميع المجموعات</option>');
                    return;
                }

                $.ajax({
                    url: '{{ route('ClientReport.getRegionGroups') }}',
                    method: 'GET',
                    data: { branch_id: branchId },
                    success: function(groups) {
                        $('#region_group').empty().append('<option value="">جميع المجموعات</option>');
                        groups.forEach(function(group) {
                            $('#region_group').append(`<option value="${group.id}">${group.name}</option>`);
                        });
                    },
                    error: function() {
                        showAlert('خطأ في تحميل المجموعات', 'danger');
                    }
                });
            }

            // دالة تحديث عرض التقرير
            function updateReportDisplay(data) {
                // تحديث الإجماليات مع تأثير العد التصاعدي
                animateValue('#totalClients', 0, data.totals.total_clients, 1000);
                animateValue('#clientsWithLocations', 0, data.totals.clients_with_locations, 1000);
                animateValue('#totalBranches', 0, data.totals.total_branches, 1000);
                animateValue('#totalNeighborhoods', 0, data.totals.total_neighborhoods, 1000);

                // تحديث عنوان التقرير
                $('#reportTitle').html(`
                    <i class="fas fa-table me-2"></i>
                    تقرير دليل العملاء - تجميع حسب ${data.group_by || 'العميل'}
                `);

                // تحديث جدول البيانات
                updateTableBody(data.clients);

                // تحديث الخريطة
                if (data.clients && data.clients.length > 0) {
                    updateMapMarkers(data.clients);
                }
            }

            // دالة تحديث محتوى الجدول
            function updateTableBody(clients) {
                let tableHtml = '';

                if (clients && clients.length > 0) {
                    clients.forEach((client, index) => {
                        const hasLocation = client.locations && client.locations.latitude && client.locations.longitude;

                        tableHtml += `<tr data-client-id="${client.id}">`;
                        tableHtml += `<td>${index + 1}</td>`;
                        tableHtml += `<td><span class="badge bg-secondary">${client.code || 'غير محدد'}</span></td>`;
                        tableHtml += `<td>
                            <div class="d-flex align-items-center">
                                <div class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <div class="fw-bold">${client.trade_name || 'غير محدد'}</div>
                                    ${client.email ? `<small class="text-muted">${client.email}</small>` : ''}
                                </div>
                            </div>
                        </td>`;
                        tableHtml += `<td>${client.branch ? `<span class="badge bg-info">${client.branch}</span>` : '<span class="text-muted">غير محدد</span>'}</td>`;
                        tableHtml += `<td>${client.category ? `<span class="badge bg-success">${client.category}</span>` : '<span class="text-muted">غير محدد</span>'}</td>`;
                        tableHtml += `<td>${client.neighborhood ? `<span class="badge bg-warning">${client.neighborhood}</span>` : '<span class="text-muted">غير محدد</span>'}</td>`;
                        tableHtml += `<td>${client.region_group ? `<span class="badge bg-primary">${client.region_group}</span>` : '<span class="text-muted">غير محدد</span>'}</td>`;

                        if (hasLocation) {
                            tableHtml += `<td>
                                <a href="#chartSection" class="location-link"
                                    data-lat="${client.locations.latitude}"
                                    data-lng="${client.locations.longitude}"
                                    data-name="${client.trade_name}"
                                    data-code="${client.code}">
                                    <i class="fas fa-map-marker-alt"></i>
                                    عرض على الخريطة
                                </a>
                            </td>`;
                        } else {
                            tableHtml += `<td><span class="text-muted"><i class="fas fa-times-circle me-1"></i>غير متوفر</span></td>`;
                        }

                        tableHtml += `<td>${client.phone ? `<a href="tel:${client.phone}" class="text-decoration-none"><i class="fas fa-phone text-success me-1"></i>${client.phone}</a>` : '<span class="text-muted">غير متوفر</span>'}</td>`;
                        tableHtml += `<td>${client.mobile ? `<a href="tel:${client.mobile}" class="text-decoration-none"><i class="fas fa-mobile-alt text-primary me-1"></i>${client.mobile}</a>` : '<span class="text-muted">غير متوفر</span>'}</td>`;
                        tableHtml += `</tr>`;
                    });
                } else {
                    tableHtml = `
                        <tr>
                            <td colspan="10" class="text-center py-4">
                                <i class="fas fa-search fa-2x text-muted mb-2"></i>
                                <p class="text-muted mb-0">لا توجد بيانات مطابقة للفلاتر المحددة</p>
                            </td>
                        </tr>
                    `;
                }

                $('#reportTableBody').html(tableHtml);

                // إعادة ربط معالجات النقر على روابط الموقع
                $('.location-link').off('click').on('click', function(e) {
                    e.preventDefault();
                    const lat = parseFloat($(this).data('lat'));
                    const lng = parseFloat($(this).data('lng'));
                    const clientId = $(this).closest('tr').data('client-id');
                    const name = $(this).data('name');
                    const code = $(this).data('code');

                    showMapWithMarker(lat, lng, clientId, name, code);
                });
            }

            // دالة الرسوم المتحركة للأرقام
            function animateValue(element, start, end, duration) {
                const obj = $(element);
                const range = Math.abs(end - start);

                if (range < 1) {
                    obj.text(end);
                    return;
                }

                const startTime = Date.now();
                const timer = setInterval(function() {
                    const elapsed = Date.now() - startTime;
                    const progress = Math.min(elapsed / duration, 1);

                    const current = start + (end - start) * progress;
                    obj.text(Math.round(current));

                    if (progress >= 1) {
                        obj.text(end);
                        clearInterval(timer);
                    }
                }, 16);
            }

            // دالة تصدير إكسل
            function exportToExcel() {
                showAlert('جاري تصدير الملف...', 'info');

                const table = document.querySelector('#reportContainer table');
                const wb = XLSX.utils.table_to_book(table, {
                    raw: false,
                    cellDates: true
                });

                const today = new Date();
                const fileName = `تقرير_دليل_العملاء_${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}.xlsx`;

                XLSX.writeFile(wb, fileName);
                showAlert('تم تصدير الملف بنجاح!', 'success');
            }

            // دالة عرض التنبيهات
            function showAlert(message, type) {
                const alertHtml = `
                    <div class="alert alert-${type} alert-dismissible fade show position-fixed"
                         style="top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
                        ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                `;

                $('body').append(alertHtml);

                setTimeout(() => {
                    $('.alert').alert('close');
                }, 3000);
            }

            // التعامل مع أزرار العرض
            $('#summaryViewBtn, #detailViewBtn').click(function() {
                $('.btn-group .btn-modern').removeClass('btn-primary-modern active').addClass('btn-outline-modern');
                $(this).removeClass('btn-outline-modern').addClass('btn-primary-modern active');

                if ($(this).attr('id') === 'summaryViewBtn') {
                    $('#chartSection').fadeIn();
                } else {
                    $('#chartSection').fadeOut();
                }
            });
        });

        // دوال الخريطة
        function initMap() {
            const mapElement = document.getElementById("clientMap");
            if (!mapElement) return;

            map = new google.maps.Map(mapElement, {
                center: { lat: 24.7136, lng: 46.6753 },
                zoom: 6,
                styles: [
                    {
                        "featureType": "poi",
                        "stylers": [{ "visibility": "off" }]
                    }
                ]
            });
            mapInitialized = true;
        }

        function showMapWithMarker(lat, lng, clientId, name, code) {
            // إظهار الخريطة
            $('#mapPlaceholder').hide();
            $('#clientMap').show();

            // التمرير إلى قسم الخريطة
            document.getElementById('chartSection').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });

            // تهيئة الخريطة إذا لم تكن مهيأة
            if (!mapInitialized) {
                initMap();
            }

            // توسيط الخريطة على الموقع المحدد
            const position = { lat, lng };
            map.setCenter(position);
            map.setZoom(15);

            // إزالة العلامات السابقة
            markers.forEach(marker => marker.setMap(null));
            markers.length = 0;

            // إضافة علامة جديدة
            const marker = new google.maps.Marker({
                position,
                map,
                title: name,
                icon: {
                    url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
                }
            });

            const infoWindow = new google.maps.InfoWindow({
                content: `
                    <div style="direction: rtl; text-align: right; min-width: 200px;">
                        ${name ? `<h6 style="margin-bottom: 5px; color: #2575fc;">${name}</h6>` : ''}
                        ${code ? `<p style="margin: 0; color: #6c757d;"><small>الكود: ${code}</small></p>` : ''}
                        <div style="margin-top: 10px;">
                            <a href="https://www.google.com/maps?q=${lat},${lng}" target="_blank"
                               style="color: #4caf50; text-decoration: none;">
                                <i class="fas fa-external-link-alt"></i> فتح في خرائط جوجل
                            </a>
                        </div>
                    </div>
                `,
            });

            marker.addListener("click", () => {
                infoWindow.open(map, marker);
            });

            markers.push(marker);

            // تحريك العلامة
            marker.setAnimation(google.maps.Animation.BOUNCE);
            setTimeout(() => {
                marker.setAnimation(null);
            }, 1500);

            // فتح نافذة المعلومات
            infoWindow.open(map, marker);
        }

        function updateMapMarkers(clients) {
            if (!mapInitialized) return;

            // إزالة العلامات السابقة
            markers.forEach(marker => marker.setMap(null));
            markers.length = 0;

            // إضافة علامات جديدة
            clients.forEach(client => {
                if (client.locations && client.locations.latitude && client.locations.longitude) {
                    const marker = new google.maps.Marker({
                        position: {
                            lat: parseFloat(client.locations.latitude),
                            lng: parseFloat(client.locations.longitude)
                        },
                        map,
                        title: client.trade_name,
                        icon: {
                            url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
                        }
                    });

                    const infoWindow = new google.maps.InfoWindow({
                        content: `
                            <div style="direction: rtl; text-align: right; min-width: 200px;">
                                <h6 style="margin-bottom: 5px; color: #2575fc;">${client.trade_name}</h6>
                                <p style="margin: 0; color: #6c757d;"><small>الكود: ${client.code}</small></p>
                                <div style="margin-top: 10px;">
                                    <a href="https://www.google.com/maps?q=${client.locations.latitude},${client.locations.longitude}" target="_blank"
                                       style="color: #4caf50; text-decoration: none;">
                                        <i class="fas fa-external-link-alt"></i> فتح في خرائط جوجل
                                    </a>
                                </div>
                            </div>
                        `,
                    });

                    marker.addListener("click", () => {
                        infoWindow.open(map, marker);
                    });

                    markers.push(marker);
                }
            });
        }

        // تأثيرات hover للكروت
        $('.stats-card').hover(
            function() {
                $(this).css('transform', 'translateY(-8px) scale(1.02)');
            },
            function() {
                $(this).css('transform', 'translateY(0) scale(1)');
            }
        );

        // تأثيرات hover للأزرار
        $('.btn-modern').hover(
            function() {
                if (!$(this).hasClass('active')) {
                    $(this).css('transform', 'translateY(-2px)');
                }
            },
            function() {
                if (!$(this).hasClass('active')) {
                    $(this).css('transform', 'translateY(0)');
                }
            }
        );

        // CSS إضافي
        const additionalCSS = `
            <style>
                .avatar-sm {
                    width: 35px;
                    height: 35px;
                    font-size: 14px;
                }

                .map-container {
                    height: 500px;
                    border-radius: 12px;
                    overflow: hidden;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
                }

                #mapPlaceholder {
                    height: 500px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
                    position: relative;
                    overflow: hidden;
                }

                #mapPlaceholder::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-image:
                        radial-gradient(circle at 25% 25%, rgba(106, 17, 203, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 75% 75%, rgba(37, 117, 252, 0.1) 0%, transparent 50%);
                }

                .placeholder-content {
                    text-align: center;
                    z-index: 1;
                    position: relative;
                }

                .placeholder-content i {
                    font-size: 4rem;
                    color: var(--primary-color);
                    margin-bottom: 1rem;
                    opacity: 0.7;
                }

                .placeholder-content h5 {
                    color: var(--dark-color);
                    font-weight: 600;
                    margin-bottom: 0.5rem;
                }

                .placeholder-content p {
                    color: var(--gray-600);
                    margin: 0;
                }

                .location-link {
                    color: var(--primary-color);
                    text-decoration: none;
                    font-weight: 600;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.5rem 1rem;
                    border-radius: 20px;
                    background: rgba(106, 17, 203, 0.1);
                    transition: var(--transition);
                }

                .location-link:hover {
                    background: var(--primary-color);
                    color: white;
                    transform: translateY(-2px);
                    box-shadow: 0 4px 15px rgba(106, 17, 203, 0.3);
                }

                .loading-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(255, 255, 255, 0.9);
                    display: none;
                    justify-content: center;
                    align-items: center;
                    z-index: 1000;
                    backdrop-filter: blur(5px);
                }

                .spinner {
                    width: 50px;
                    height: 50px;
                    border: 4px solid var(--gray-200);
                    border-top: 4px solid var(--primary-color);
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }

                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }

                .fade-in {
                    opacity: 0;
                    transform: translateY(30px);
                    animation: fadeInUp 0.6s ease forwards;
                }

                @keyframes fadeInUp {
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            </style>
        `;

        $('head').append(additionalCSS);
    </script>
@endsection