@extends('master')

@section('title')
    تقرير أعمار ديون الفواتير
@stop

@section('css')
    <!-- Google Fonts - Cairo -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Select2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/css/select2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/report.css') }}">
    <link rel="stylesheet" href="{{ asset('css/report.css') }}">
@endsection

@section('content')
    <!-- Page Header -->
    <div class="page-header">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="slide-in">
                        <i class="fas fa-file-invoice-dollar me-3"></i>
                        تقرير أعمار ديون الفواتير
                    </h1>
                    <nav class="breadcrumb-custom">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item">
                                <a href="#"><i class="fas fa-home me-2"></i>الرئيسية</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">التقارير</a>
                            </li>
                            <li class="breadcrumb-item active">أعمار ديون الفواتير</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-md-4 text-end">
                    <div class="stats-icon primary">
                        <i class="fas fa-file-invoice-dollar"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <!-- Filters Section -->
        <div class="card-modern fade-in">
            <div class="card-header-modern">
                <h5 class="mb-0">
                    <i class="fas fa-filter me-2"></i>
                    فلاتر التقرير
                </h5>
            </div>
            <div class="card-body-modern">
                <form id="reportForm">
                    <div class="row g-4">
                        <!-- First Row -->
                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">العميل</label>
                            <select name="customer" id="customer" class="form-control select2-ajax">
                                <option value="">جميع العملاء</option>
                                @foreach ($customers as $customer)
                                    <option value="{{ $customer->id }}">{{ $customer->trade_name }} ({{ $customer->code }})</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">الفرع</label>
                            <select name="branch" id="branch" class="form-control select2">
                                <option value="">جميع الفروع</option>
                                @foreach ($branches as $branch)
                                    <option value="{{ $branch->id }}">{{ $branch->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">تصنيف العميل</label>
                            <select name="customer_type" id="customer_type" class="form-control select2">
                                <option value="">جميع التصنيفات</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">مسؤول المبيعات</label>
                            <select name="sales_manager" id="sales_manager" class="form-control select2">
                                <option value="">جميع المسؤولين</option>
                                @foreach ($salesManagers as $manager)
                                    <option value="{{ $manager->id }}">{{ $manager->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Second Row -->
                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">تمت الإضافة بواسطة</label>
                            <select name="added_by" id="added_by" class="form-control select2">
                                <option value="">الكل</option>
                                @foreach ($salesManagers as $employee)
                                    <option value="{{ $employee->id }}">{{ $employee->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">السنة المالية</label>
                            <select id="financial-year" name="financial_year[]" class="form-control select2" multiple>
                                <option value="current">السنة المفتوحة</option>
                                <option value="all">جميع السنوات</option>
                                @for ($year = date('Y'); $year >= date('Y') - 10; $year--)
                                    <option value="{{ $year }}">{{ $year }}</option>
                                @endfor
                            </select>
                        </div>

                        <!-- Date Range -->
                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">من تاريخ</label>
                            <input type="date" name="from_date" id="from_date" class="form-control"
                                value="{{ now()->startOfMonth()->format('Y-m-d') }}">
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <label class="form-label-modern">إلى تاريخ</label>
                            <input type="date" name="to_date" id="to_date" class="form-control"
                                value="{{ now()->format('Y-m-d') }}">
                        </div>

                        <!-- Action Buttons -->
                        <div class="col-lg-12 align-self-end">
                            <div class="d-flex gap-2 flex-wrap justify-content-center">
                                <button type="button" class="btn-modern btn-primary-modern" id="filterBtn">
                                    <i class="fas fa-search"></i>
                                    عرض التقرير
                                </button>
                                <button type="button" class="btn-modern btn-outline-modern" id="resetBtn">
                                    <i class="fas fa-refresh"></i>
                                    إلغاء الفلتر
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="card-modern no-print fade-in">
            <div class="card-body-modern">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <div class="d-flex gap-2 flex-wrap">
                        <button class="btn-modern btn-success-modern" id="exportExcel">
                            <i class="fas fa-file-excel"></i>
                            تصدير إكسل
                        </button>
                        <button class="btn-modern btn-warning-modern" id="printBtn">
                            <i class="fas fa-print"></i>
                            طباعة
                        </button>
                    </div>

                    <div class="btn-group" role="group">
                        <button type="button" class="btn-modern btn-primary-modern active" id="summaryViewBtn">
                            <i class="fas fa-chart-pie"></i>
                            ملخص
                        </button>
                        <button type="button" class="btn-modern btn-outline-modern" id="detailViewBtn">
                            <i class="fas fa-list"></i>
                            تفاصيل
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4 fade-in" id="totalsSection">
            <div class="col-lg-2 col-md-4 mb-3">
                <div class="stats-card">
                    <div class="stats-icon primary">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stats-value" id="todayAmount">0.00</div>
                    <div class="stats-label">اليوم (ريال)</div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-3">
                <div class="stats-card warning">
                    <div class="stats-icon warning">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                    <div class="stats-value" id="days1to30">0.00</div>
                    <div class="stats-label">1-30 يوم (ريال)</div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-3">
                <div class="stats-card info">
                    <div class="stats-icon info">
                        <i class="fas fa-calendar-week"></i>
                    </div>
                    <div class="stats-value" id="days31to60">0.00</div>
                    <div class="stats-label">31-60 يوم (ريال)</div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-3">
                <div class="stats-card success">
                    <div class="stats-icon success">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="stats-value" id="days61to90">0.00</div>
                    <div class="stats-label">61-90 يوم (ريال)</div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-3">
                <div class="stats-card danger">
                    <div class="stats-icon danger">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stats-value" id="days91to120">0.00</div>
                    <div class="stats-label">91-120 يوم (ريال)</div>
                </div>
            </div>

            <div class="col-lg-2 col-md-4 mb-3">
                <div class="stats-card dark">
                    <div class="stats-icon dark">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stats-value" id="daysOver120">0.00</div>
                    <div class="stats-label">+120 يوم (ريال)</div>
                </div>
            </div>
        </div>

        <!-- Chart Section -->
        <div class="card-modern fade-in" id="chartSection">
            <div class="card-header-modern">
                <h5 class="mb-0">
                    <i class="fas fa-chart-bar me-2"></i>
                    الرسم البياني لأعمار ديون الفواتير
                </h5>
            </div>
            <div class="card-body-modern">
                <div class="chart-container">
                    <canvas class="chart bg-light" id="agingChart" style="height: 400px;"></canvas>
                </div>
            </div>
        </div>

        <!-- Report Table -->
        <div class="card-modern fade-in" id="reportContainer" style="position: relative;">
            <!-- Loading Overlay -->
            <div class="loading-overlay">
                <div class="spinner"></div>
            </div>

            <div class="card-header-modern">
                <h5 class="mb-0" id="reportTitle">
                    <i class="fas fa-table me-2"></i>
                    تقرير أعمار ديون الفواتير
                </h5>
                <div class="mt-2">
                    <small class="text-muted" id="recordsInfo">
                        عدد السجلات: <span id="recordCount">0</span> |
                        عدد العملاء: <span id="clientCount">0</span>
                    </small>
                </div>
            </div>
            <div class="card-body-modern p-0">
                <div class="table-responsive">
                    <table class="table table-modern mb-0" id="reportTable">
                        <thead>
                            <tr>
                                <th><i class="fas fa-hashtag me-2"></i>رقم الفاتورة</th>
                                <th><i class="fas fa-code me-2"></i>كود العميل</th>
                                <th><i class="fas fa-hashtag me-2"></i>رقم الحساب</th>
                                <th><i class="fas fa-user-tie me-2"></i>اسم العميل</th>
                                <th><i class="fas fa-building me-2"></i>الفرع</th>
                                <th><i class="fas fa-calendar me-2"></i>تاريخ الفاتورة</th>
                                <th><i class="fas fa-hourglass-half me-2"></i>عدد الأيام</th>
                                <th><i class="fas fa-clock me-2"></i>اليوم (ريال)</th>
                                <th><i class="fas fa-calendar-day me-2"></i>1-30 يوم (ريال)</th>
                                <th><i class="fas fa-calendar-week me-2"></i>31-60 يوم (ريال)</th>
                                <th><i class="fas fa-calendar-alt me-2"></i>61-90 يوم (ريال)</th>
                                <th><i class="fas fa-exclamation-triangle me-2"></i>91-120 يوم (ريال)</th>
                                <th><i class="fas fa-times-circle me-2"></i>+120 يوم (ريال)</th>
                                <th><i class="fas fa-calculator me-2"></i>الإجمالي (ريال)</th>
                            </tr>
                        </thead>
                        <tbody id="reportTableBody">
                            <!-- سيتم تحديث البيانات هنا عبر AJAX -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.5/xlsx.full.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Select2 JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/js/select2.min.js"></script>

    <script>
        let agingChart;

        $(document).ready(function() {
            // تهيئة Select2 العادي
            $('.select2').select2({
                theme: 'bootstrap-5',
                dir: 'rtl',
                language: {
                    noResults: function() {
                        return "لا توجد نتائج";
                    },
                    searching: function() {
                        return "جاري البحث...";
                    },
                    loadingMore: function() {
                        return "جاري تحميل المزيد...";
                    }
                },
                allowClear: true,
                width: '100%',
                dropdownParent: $('body'),
                minimumResultsForSearch: 0,
                placeholder: function() {
                    return $(this).data('placeholder') || 'اختر...';
                },
                dropdownCssClass: 'select2-dropdown-custom',
                minimumInputLength: 0,
                closeOnSelect: true,
                selectOnClose: false
            });

            // تهيئة Select2 مع AJAX للعملاء
            $('#customer').select2({
                theme: 'bootstrap-5',
                dir: 'rtl',
                language: {
                    noResults: function() {
                        return "لا توجد نتائج";
                    },
                    searching: function() {
                        return "جاري البحث...";
                    },
                    loadingMore: function() {
                        return "جاري تحميل المزيد...";
                    },
                    inputTooShort: function() {
                        return "يرجى كتابة حرف واحد على الأقل";
                    }
                },
                allowClear: true,
                width: '100%',
                dropdownParent: $('body'),
                placeholder: 'ابحث عن عميل...',
                minimumInputLength: 1,
                ajax: {
                    url: '{{ route('ClientReport.searchClients') }}', // تحتاج لإضافة هذا الراوت
                    dataType: 'json',
                    delay: 300,
                    data: function (params) {
                        return {
                            q: params.term,
                            page: params.page || 1
                        };
                    },
                    processResults: function (data, params) {
                        params.page = params.page || 1;
                        return {
                            results: data.results,
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    },
                    cache: true
                },
                escapeMarkup: function (markup) {
                    return markup;
                },
                templateResult: function(client) {
                    if (client.loading) {
                        return 'جاري البحث...';
                    }

                    var $container = $(
                        "<div class='select2-result-repository clearfix'>" +
                            "<div class='select2-result-repository__avatar'><i class='fas fa-user-tie'></i></div>" +
                            "<div class='select2-result-repository__meta'>" +
                                "<div class='select2-result-repository__title'></div>" +
                                "<div class='select2-result-repository__description'></div>" +
                            "</div>" +
                        "</div>"
                    );

                    $container.find(".select2-result-repository__title").text(client.text);
                    $container.find(".select2-result-repository__description").text(client.title || '');

                    return $container;
                },
                templateSelection: function(client) {
                    return client.text || client.text;
                }
            });

            // تخصيص تصميم Select2
            $('.select2-container--bootstrap-5 .select2-selection--single').css({
                'border': '2px solid var(--gray-200)',
                'border-radius': '12px',
                'height': 'auto',
                'padding': '0.5rem 1rem',
                'min-height': '48px'
            });

            // تحميل البيانات الأولية
            loadReportData();
            initializeChart();

            // Add animation classes on load
            setTimeout(() => {
                $('.fade-in').addClass('animate__animated animate__fadeInUp');
            }, 100);

            // التعامل مع تصفية التقرير
            $('#filterBtn').click(function() {
                $(this).addClass('loading');
                loadReportData();
            });

            // إعادة تعيين الفلاتر
            $('#resetBtn').click(function() {
                $('#reportForm')[0].reset();
                $('.select2').val(null).trigger('change');
                $('#from_date').val('{{ now()->startOfMonth()->format('Y-m-d') }}');
                $('#to_date').val('{{ now()->format('Y-m-d') }}');
                loadReportData();
            });

            // التعامل مع تصدير إكسل
            $('#exportExcel').click(function() {
                exportToExcel();
            });

            // التعامل مع الطباعة
            $('#printBtn').click(function() {
                window.print();
            });

            // تحديث البيانات عند تغيير أي فلتر
            $('.select2, #reportForm input').on('change', function() {
                loadReportData();
            });

            // دالة تحميل بيانات التقرير
            function loadReportData() {
                $('.loading-overlay').fadeIn();
                $('#filterBtn').prop('disabled', true);

                const formData = $('#reportForm').serialize();

                $.ajax({
                    url: '{{ route('ClientReport.invoiceDebtAgingAjax') }}',
                    method: 'GET',
                    data: formData,
                    success: function(response) {
                        updateReportDisplay(response);
                        $('.loading-overlay').fadeOut();
                        $('#filterBtn').prop('disabled', false);
                        $('#filterBtn').removeClass('loading');
                        $('#reportContainer').addClass('fade-in');
                    },
                    error: function(xhr, status, error) {
                        console.error('خطأ في تحميل البيانات:', error);
                        $('.loading-overlay').fadeOut();
                        $('#filterBtn').prop('disabled', false);
                        $('#filterBtn').removeClass('loading');
                        showAlert('حدث خطأ في تحميل البيانات. يرجى المحاولة مرة أخرى.', 'danger');
                    }
                });
            }

            // دالة تحديث عرض التقرير
            function updateReportDisplay(data) {
                // تحديث الإجماليات مع تأثير العد التصاعدي
                animateValue('#todayAmount', 0, data.totals.today, 1000);
                animateValue('#days1to30', 0, data.totals.days1to30, 1000);
                animateValue('#days31to60', 0, data.totals.days31to60, 1000);
                animateValue('#days61to90', 0, data.totals.days61to90, 1000);
                animateValue('#days91to120', 0, data.totals.days91to120, 1000);
                animateValue('#daysOver120', 0, data.totals.daysOver120, 1000);

                // تحديث معلومات العد
                $('#recordCount').text(data.count || 0);
                $('#clientCount').text(data.clients_count || 0);

                // تحديث عنوان التقرير
                $('#reportTitle').html(`
                    <i class="fas fa-table me-2"></i>
                    تقرير أعمار ديون الفواتير من ${data.from_date} إلى ${data.to_date}
                `);

                // تحديث جدول البيانات
                updateTableBody(data.grouped_clients, data.totals);

                // تحديث الرسم البياني
                updateChart(data.chart_data);
            }

            // دالة تحديث محتوى الجدول - معدلة لإظهار كل العملاء
            function updateTableBody(groupedClients, totals) {
                let tableHtml = '';
                let grandTotals = {
                    today: 0,
                    days1to30: 0,
                    days31to60: 0,
                    days61to90: 0,
                    days91to120: 0,
                    daysOver120: 0,
                    total_due: 0
                };

                // التحقق من وجود بيانات
                if (!groupedClients || Object.keys(groupedClients).length === 0) {
                    tableHtml = `
                        <tr>
                            <td colspan="14" class="text-center py-4">
                                <i class="fas fa-info-circle me-2"></i>
                                لا توجد بيانات لعرضها
                            </td>
                        </tr>
                    `;
                } else {
                    // تكرار عبر المجموعات
                    Object.keys(groupedClients).forEach(clientName => {
                        const clientGroup = groupedClients[clientName];
                        const clientData = clientGroup.data;

                        // صف رأس العميل (إذا كان هناك أكثر من فاتورة)
                        if (clientData.length > 1) {
                            tableHtml += `
                                <tr class="table-client-header">
                                    <td colspan="14">
                                        <i class="fas fa-user-tie me-2"></i>
                                        <strong>${clientName}</strong>
                                        <span class="badge bg-primary ms-2">${clientData.length} فاتورة</span>
                                    </td>
                                </tr>
                            `;
                        }

                        // تكرار عبر فواتير العميل
                        clientData.forEach((item, index) => {
                            const isOverdue = (item.days91to120 > 0 || item.daysOver120 > 0);
                            const rowClass = isOverdue ? 'table-warning' : '';

                            tableHtml += `<tr class="${rowClass}">`;
                            tableHtml += `<td>
                                <span class="fw-bold text-primary">${item.invoice_number}</span>
                            </td>`;
                            tableHtml += `<td>${item.client_code}</td>`;
                            tableHtml += `<td>${item.account_number}</td>`;
                            tableHtml += `<td>
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-user-tie me-2 text-primary"></i>
                                    <div>
                                        <div class="fw-bold">${item.client_name}</div>
                                        <small class="text-muted">${item.client_email || ''}</small>
                                    </div>
                                </div>
                            </td>`;
                            tableHtml += `<td>${item.branch}</td>`;
                            tableHtml += `<td>
                                <span class="badge bg-light text-dark">${item.invoice_date}</span>
                            </td>`;
                            tableHtml += `<td>
                                <span class="badge ${getDaysLateBadgeClass(item.days_late)}">${item.days_late} يوم</span>
                            </td>`;

                            // الأعمدة المالية مع الألوان
                            tableHtml += `<td class="fw-bold ${item.today > 0 ? 'text-primary' : ''}">${formatNumber(item.today)}</td>`;
                            tableHtml += `<td class="fw-bold ${item.days1to30 > 0 ? 'text-warning' : ''}">${formatNumber(item.days1to30)}</td>`;
                            tableHtml += `<td class="fw-bold ${item.days31to60 > 0 ? 'text-info' : ''}">${formatNumber(item.days31to60)}</td>`;
                            tableHtml += `<td class="fw-bold ${item.days61to90 > 0 ? 'text-success' : ''}">${formatNumber(item.days61to90)}</td>`;
                            tableHtml += `<td class="fw-bold ${item.days91to120 > 0 ? 'text-danger' : ''}">${formatNumber(item.days91to120)}</td>`;
                            tableHtml += `<td class="fw-bold ${item.daysOver120 > 0 ? 'text-dark' : ''}">${formatNumber(item.daysOver120)}</td>`;
                            tableHtml += `<td class="fw-bold text-primary">${formatNumber(item.total_due)}</td>`;
                            tableHtml += `</tr>`;

                            // تجميع الإجماليات
                            grandTotals.today += parseFloat(item.today);
                            grandTotals.days1to30 += parseFloat(item.days1to30);
                            grandTotals.days31to60 += parseFloat(item.days31to60);
                            grandTotals.days61to90 += parseFloat(item.days61to90);
                            grandTotals.days91to120 += parseFloat(item.days91to120);
                            grandTotals.daysOver120 += parseFloat(item.daysOver120);
                            grandTotals.total_due += parseFloat(item.total_due);
                        });

                        // صف إجمالي العميل (إذا كان هناك أكثر من فاتورة)
                        if (clientData.length > 1) {
                            const clientTotals = clientGroup.client_totals;
                            tableHtml += `
                                <tr class="table-client-total">
                                    <td colspan="7">
                                        <i class="fas fa-calculator me-2"></i>
                                        <strong>مجموع ${clientName}</strong>
                                    </td>
                                    <td class="fw-bold">${formatNumber(clientTotals.today)}</td>
                                    <td class="fw-bold">${formatNumber(clientTotals.days1to30)}</td>
                                    <td class="fw-bold">${formatNumber(clientTotals.days31to60)}</td>
                                    <td class="fw-bold">${formatNumber(clientTotals.days61to90)}</td>
                                    <td class="fw-bold">${formatNumber(clientTotals.days91to120)}</td>
                                    <td class="fw-bold">${formatNumber(clientTotals.daysOver120)}</td>
                                    <td class="fw-bold">${formatNumber(clientTotals.total_due)}</td>
                                </tr>
                            `;
                        }
                    });

                    // صف الإجمالي العام
                    if (Object.keys(groupedClients).length > 0) {
                        tableHtml += `
                            <tr class="table-grand-total">
                                <td colspan="7">
                                    <i class="fas fa-chart-bar me-2"></i>
                                    <strong>المجموع الكلي</strong>
                                </td>
                                <td class="fw-bold">${formatNumber(grandTotals.today)}</td>
                                <td class="fw-bold">${formatNumber(grandTotals.days1to30)}</td>
                                <td class="fw-bold">${formatNumber(grandTotals.days31to60)}</td>
                                <td class="fw-bold">${formatNumber(grandTotals.days61to90)}</td>
                                <td class="fw-bold">${formatNumber(grandTotals.days91to120)}</td>
                                <td class="fw-bold">${formatNumber(grandTotals.daysOver120)}</td>
                                <td class="fw-bold">${formatNumber(grandTotals.total_due)}</td>
                            </tr>
                        `;
                    }
                }

                $('#reportTableBody').html(tableHtml);
            }

            // دالة للحصول على كلاس الـ badge حسب عدد الأيام المتأخرة
            function getDaysLateBadgeClass(daysLate) {
                if (daysLate === 0) return 'bg-primary';
                if (daysLate <= 30) return 'bg-warning';
                if (daysLate <= 60) return 'bg-info';
                if (daysLate <= 90) return 'bg-success';
                if (daysLate <= 120) return 'bg-danger';
                return 'bg-dark';
            }

            // دالة تهيئة الرسم البياني
            function initializeChart() {
                const ctx = document.getElementById('agingChart').getContext('2d');

                agingChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['اليوم', '1-30 يوم', '31-60 يوم', '61-90 يوم', '91-120 يوم', '+120 يوم'],
                        datasets: [{
                            label: 'أعمار ديون الفواتير (ريال)',
                            data: [0, 0, 0, 0, 0, 0],
                            backgroundColor: [
                                'rgba(54, 162, 235, 0.8)',
                                'rgba(255, 193, 7, 0.8)',
                                'rgba(23, 162, 184, 0.8)',
                                'rgba(40, 167, 69, 0.8)',
                                'rgba(220, 53, 69, 0.8)',
                                'rgba(52, 58, 64, 0.8)'
                            ],
                            borderColor: [
                                'rgba(54, 162, 235, 1)',
                                'rgba(255, 193, 7, 1)',
                                'rgba(23, 162, 184, 1)',
                                'rgba(40, 167, 69, 1)',
                                'rgba(220, 53, 69, 1)',
                                'rgba(52, 58, 64, 1)'
                            ],
                            borderWidth: 2,
                            borderRadius: 8,
                            borderSkipped: false,
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            title: {
                                display: true,
                                text: 'توزيع أعمار ديون الفواتير',
                                font: {
                                    size: 18,
                                    weight: 'bold'
                                }
                            },
                            legend: {
                                display: false
                            },
                            tooltip: {
                                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                                titleFont: {
                                    size: 14,
                                    weight: 'bold'
                                },
                                bodyFont: {
                                    size: 12
                                },
                                callbacks: {
                                    label: function(context) {
                                        return 'المبلغ: ' + formatNumber(context.parsed.y) + ' ريال';
                                    }
                                }
                            }
                        },
                        scales: {
                            x: {
                                grid: {
                                    display: false
                                },
                                ticks: {
                                    font: {
                                        size: 12,
                                        weight: 'bold'
                                    }
                                }
                            },
                            y: {
                                beginAtZero: true,
                                grid: {
                                    color: 'rgba(0, 0, 0, 0.1)'
                                },
                                ticks: {
                                    callback: function(value) {
                                        if (value >= 1000000) {
                                            return (value / 1000000).toFixed(1) + 'M';
                                        } else if (value >= 1000) {
                                            return (value / 1000).toFixed(0) + 'K';
                                        }
                                        return value;
                                    },
                                    font: {
                                        size: 12
                                    }
                                },
                                title: {
                                    display: true,
                                    text: 'المبلغ (ريال)',
                                    font: {
                                        size: 14,
                                        weight: 'bold'
                                    }
                                }
                            }
                        },
                        animation: {
                            duration: 1500,
                            easing: 'easeInOutQuart'
                        }
                    }
                });
            }

            // دالة تحديث الرسم البياني
            function updateChart(chartData) {
                if (agingChart && chartData.aging_values) {
                    agingChart.data.datasets[0].data = chartData.aging_values;
                    agingChart.update('active');
                }
            }

            // دالة تنسيق الأرقام
            function formatNumber(number) {
                return parseFloat(number).toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            // دالة الرسوم المتحركة للأرقام
            function animateValue(element, start, end, duration) {
                const obj = $(element);
                const range = Math.abs(end - start);

                // إذا كان الفرق صغير جداً أو صفر، اعرض القيمة النهائية مباشرة
                if (range < 1) {
                    obj.text(formatNumber(end));
                    return;
                }

                const startTime = Date.now();
                const timer = setInterval(function() {
                    const elapsed = Date.now() - startTime;
                    const progress = Math.min(elapsed / duration, 1);

                    const current = start + (end - start) * progress;
                    obj.text(formatNumber(Math.round(current)));

                    // توقف عند اكتمال الرسوم المتحركة
                    if (progress >= 1) {
                        obj.text(formatNumber(end));
                        clearInterval(timer);
                    }
                }, 16); // 60 FPS تقريباً
            }

            // دالة تصدير إكسل
            function exportToExcel() {
                showAlert('جاري تصدير الملف...', 'info');

                const table = document.querySelector('#reportContainer table');
                const wb = XLSX.utils.table_to_book(table, {
                    raw: false,
                    cellDates: true
                });

                const today = new Date();
                const fileName = `تقرير_أعمار_ديون_الفواتير_${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}.xlsx`;

                XLSX.writeFile(wb, fileName);
                showAlert('تم تصدير الملف بنجاح!', 'success');
            }

            // دالة عرض التنبيهات
            function showAlert(message, type) {
                const alertHtml = `
                    <div class="alert alert-${type} alert-dismissible fade show position-fixed"
                         style="top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
                        ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                `;

                $('body').append(alertHtml);

                // إزالة التنبيه تلقائياً بعد 3 ثوان
                setTimeout(() => {
                    $('.alert').alert('close');
                }, 3000);
            }

            // التعامل مع أزرار العرض
            $('#summaryViewBtn, #detailViewBtn').click(function() {
                $('.btn-group .btn-modern').removeClass('btn-primary-modern active').addClass('btn-outline-modern');
                $(this).removeClass('btn-outline-modern').addClass('btn-primary-modern active');

                if ($(this).attr('id') === 'summaryViewBtn') {
                    $('#chartSection').fadeIn();
                    showAlert('تم التبديل إلى عرض الملخص', 'info');
                } else {
                    $('#chartSection').fadeOut();
                    showAlert('تم التبديل إلى عرض التفاصيل', 'info');
                }
            });

            // تأثيرات hover للكروت
            $('.stats-card').hover(
                function() {
                    $(this).css('transform', 'translateY(-8px) scale(1.02)');
                },
                function() {
                    $(this).css('transform', 'translateY(0) scale(1)');
                }
            );

            // تأثيرات hover للأزرار
            $('.btn-modern').hover(
                function() {
                    if (!$(this).hasClass('active')) {
                        $(this).css('transform', 'translateY(-2px)');
                    }
                },
                function() {
                    if (!$(this).hasClass('active')) {
                        $(this).css('transform', 'translateY(0)');
                    }
                }
            );

            // تحسين UX - تلميحات الأدوات
            $('[data-bs-toggle="tooltip"]').tooltip();
        });

        // CSS إضافي للتحسينات


        $('head').append(additionalCSS);
    </script>

@endsection
